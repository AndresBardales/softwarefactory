# ==============================================================================
# BIGDATA LAB - TERRAFORM VARIABLES
# ==============================================================================
# Proyecto 100% aislado de Kaanbal Engine
# Cuenta AWS nueva (feb 2026) — región México
# ==============================================================================

# --- AWS Credentials (actualizadas - nueva cuenta) ---
aws_region     = "mx-central-1"
aws_access_key = "AKIAU5P2PE2OWJ2K27UV"
aws_secret_key = "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"

# --- Cluster ---
project_name  = "bigdata-lab"
instance_type = "m7i-flex.large"   # 2 vCPU, 8 GiB
disk_size_gb  = 50
worker_count  = 2                  # 1 master + 2 workers = 3 nodos

# --- K3s ---
k3s_version = "v1.29.0+k3s1"

# --- Elastic IP (nueva cuenta — reutilizar la existente en mx-central-1) ---
elastic_ip_allocation_id = "eipalloc-076f1da8ec1d43053"

# --- Seguridad ---
# Tu IP pública para SSH/K8s API (0.0.0.0/0 = abierto a todos, cambiar si quieres)
allowed_ssh_cidr = "0.0.0.0/0"
