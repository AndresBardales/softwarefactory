"""
App Deployer Service
====================
Replica la lógica de tu flujo de n8n para crear apps:
1. Crear proyecto/repo en Bitbucket
2. Clonar template
3. Personalizar archivos (sed replacements)
4. Push al nuevo repo
5. Agregar manifests k8s a infra-gitops
6. Push infra-gitops (ArgoCD detecta y despliega)

Soporta múltiples ambientes: dev, staging, prod
"""

import os
import re
import shutil
import subprocess
import logging
import secrets as secrets_module
import string
from typing import Optional
from datetime import datetime
from bson import ObjectId
import httpx

from app.config import settings
from app.defaults import (
    VAULT_ADDR,
    VAULT_HOSTNAME,
    TEMPLATES_REPO,
    PIPELINE_EMAIL_DOMAIN_FALLBACK,
    TAILSCALE_DNS_SUFFIX,
    TAILSCALE_API_BASE,
    TAILSCALE_OAUTH_URL,
)

logger = logging.getLogger(__name__)

from app.models import AppCreate, WebhookDeployRequest, CreationMode
from app.db import get_db
from app.services.template_service import TemplateService
from app.services.template_spec import TemplateSpec
from app.services.git_provider import GitProvider, get_git_provider, build_provider_from_config


class AppDeployer:
    def __init__(self):
        self.workspace = settings.workspace_path
        self.bb_workspace = settings.bitbucket_workspace
        # Credenciales se cargan dinámicamente desde MongoDB
        self._credentials = None
        self.template_service = TemplateService()
        # Git provider (loaded lazily via _load_credentials)
        self._provider: GitProvider | None = None
    
    async def _load_credentials(self, provider_override: str = None):
        """Carga credenciales desde MongoDB (system_config) y construye el git provider"""
        if self._credentials and self._provider and not provider_override:
            return self._credentials
            
        db = get_db()
        config = await db.system_config.find_one({"_id": "main"})
        
        if config:
            self._credentials = {
                "git_user": config.get("git_username", settings.git_username),
                "git_token": config.get("git_token", settings.git_token),
                "bb_workspace": config.get("bitbucket_workspace", settings.bitbucket_workspace),
                "domain": config.get("domain", settings.domain),
                "dockerhub_username": config.get("dockerhub_username", settings.dockerhub_username),
                "dockerhub_token": config.get("dockerhub_token", settings.dockerhub_token),
                "bitbucket_email": config.get("bitbucket_email", ""),
                "templates_repo": config.get("templates_repo", TEMPLATES_REPO),
                "tailscale_dns_suffix": config.get("tailscale_dns_suffix", TAILSCALE_DNS_SUFFIX),
                "tailscale_client_id": config.get("tailscale_client_id", ""),
                "tailscale_client_secret": config.get("tailscale_client_secret", ""),
                "vault_addr": config.get("vault_addr", VAULT_ADDR),
                "vault_token": config.get("vault_token", ""),
                "vault_hostname": config.get("vault_hostname", VAULT_HOSTNAME),
                "elastic_ip": config.get("cluster_ssh_host", ""),
                "ssh_key_path": config.get("ssh_key_path", ""),
                # Git provider selection
                "git_provider": config.get("git_provider", "bitbucket"),
                # GitHub-specific
                "github_org": config.get("github_org", ""),
                "github_token": config.get("github_token", "") or config.get("git_token", ""),
                "github_is_org": config.get("github_is_org", False),
                # Cloudflare
                "cloudflare_token": config.get("cloudflare_token", ""),
                "cloudflare_account_id": config.get("cloudflare_account_id", ""),
                "cloudflare_tunnel_id": config.get("cloudflare_tunnel_id", ""),
                "cloudflare_zone_id": config.get("cloudflare_zone_id", ""),
            }
        else:
            # Fallback a settings/env vars
            self._credentials = {
                "git_user": settings.git_username,
                "git_token": settings.git_token,
                "bb_workspace": settings.bitbucket_workspace,
                "domain": settings.domain,
                "dockerhub_username": settings.dockerhub_username,
                "dockerhub_token": settings.dockerhub_token,
                "bitbucket_email": "",
                "templates_repo": TEMPLATES_REPO,
                "tailscale_dns_suffix": TAILSCALE_DNS_SUFFIX,
                "tailscale_client_id": "",
                "tailscale_client_secret": "",
                "vault_addr": VAULT_ADDR,
                "vault_token": "",
                "vault_hostname": VAULT_HOSTNAME,
                "elastic_ip": "",
                "ssh_key_path": "",
                "git_provider": "bitbucket",
                "github_org": "",
                "github_token": "",
                "github_is_org": False,
                # Cloudflare
                "cloudflare_token": "",
                "cloudflare_account_id": "",
                "cloudflare_tunnel_id": "",
                "cloudflare_zone_id": "",
            }
        
        # Build git provider
        provider_name = provider_override or self._credentials.get("git_provider", "bitbucket")
        self._provider = get_git_provider(provider_name, self._credentials)
        
        return self._credentials
    
    @property
    def provider(self) -> GitProvider:
        """Current git provider (set during _load_credentials)"""
        if not self._provider:
            raise RuntimeError("Call _load_credentials() before accessing provider")
        return self._provider
    @property
    def git_user(self):
        return self._credentials["git_user"] if self._credentials else settings.git_username
    
    @property
    def git_token(self):
        return self._credentials["git_token"] if self._credentials else settings.git_token
    
    @property
    def domain(self):
        return self._credentials["domain"] if self._credentials else settings.domain

    def _is_root_domain_request(self, app_data: AppCreate) -> bool:
        cfg = getattr(app_data, "template_config", {}) or {}
        for key in ("use_root_domain", "root_domain", "is_root_app"):
            val = cfg.get(key)
            if isinstance(val, bool) and val:
                return True
            if isinstance(val, str) and val.strip().lower() in {"1", "true", "yes", "on", "y"}:
                return True
            if isinstance(val, (int, float)) and val != 0:
                return True
        return False

    def _build_public_host(self, app_name: str, env: str, app_data: Optional[AppCreate] = None) -> str:
        use_root_domain = bool(app_data and self._is_root_domain_request(app_data))
        if env == "prod" and use_root_domain:
            return self.domain
        if env == "prod":
            return f"{app_name}.{self.domain}"
        return f"{env}-{app_name}.{self.domain}"

    def _build_public_host_tokenized(self, app_name: str, env: str, app_data: Optional[AppCreate] = None) -> str:
        use_root_domain = bool(app_data and self._is_root_domain_request(app_data))
        if env == "prod" and use_root_domain:
            return "__DOMAIN__"
        if env == "prod":
            return f"{app_name}.__DOMAIN__"
        return f"{env}-{app_name}.__DOMAIN__"

    def _sanitize_error(self, error_msg: str) -> str:
        """Strip credentials/tokens from error messages before exposing to users"""
        msg = str(error_msg)
        # Remove git token
        if self._credentials:
            token = self._credentials.get("git_token", "")
            if token:
                msg = msg.replace(token, "***")
            user = self._credentials.get("git_user", "")
            if user:
                msg = msg.replace(user, "***")
            email = self._credentials.get("bitbucket_email", "")
            if email:
                msg = msg.replace(email, "***")
            docker_token = self._credentials.get("dockerhub_token", "")
            if docker_token:
                msg = msg.replace(docker_token, "***")
        # Also strip from settings fallback
        for secret in [settings.git_token, settings.git_username]:
            if secret:
                msg = msg.replace(secret, "***")
        # Remove any remaining https://user:token@ patterns
        import re
        msg = re.sub(r'https://[^@]+@', 'https://***@', msg)
        return msg
        
    async def deploy(self, app_data: AppCreate, progress_callback=None) -> dict:
        """Deploy - returns when done. Optional progress_callback for SSE streaming."""

        async def emit(step: str, message: str, status: str = "running"):
            if progress_callback:
                await progress_callback({
                    "step": step,
                    "message": message,
                    "status": status,
                    "timestamp": datetime.utcnow().isoformat()
                })

        # Cargar credenciales de MongoDB (+ build git provider)
        # Allow per-deploy provider override via app_data or default from system_config
        provider_override = getattr(app_data, 'git_provider', None)
        await self._load_credentials(provider_override=provider_override)
        await emit("credentials", f"Credentials loaded (provider: {self.provider.display_name})")

        app_name = app_data.name
        template_id = app_data.template
        environments = getattr(app_data, 'environments', ['prod'])
        template_config = getattr(app_data, 'template_config', {}) or {}

        # Get template details
        await emit("template", f"Loading template: {template_id}")
        template_details = await self.template_service.get_template_details(template_id)
        if not template_details:
             raise Exception(f"Template {template_id} not found in catalog")
        await emit("template", f"Template loaded: {template_details.get('name', template_id)}", "success")

        # Build TemplateSpec — single source of truth for template behavior
        spec = TemplateSpec(template_details)

        # Auto-detect creation_mode from template if caller used default (scaffold)
        # Config-only templates (databases, EMQX, etc.) don't need repo/scaffold
        template_creation_modes = template_details.get("creation_modes", [])
        needs_repo = template_details.get("needs_repo", True)
        if app_data.creation_mode == CreationMode.SCAFFOLD:
            if not needs_repo and "config-only" in template_creation_modes:
                app_data.creation_mode = CreationMode.CONFIG_ONLY
                await emit("template", "Auto-detected config-only mode (no repo needed)")
            elif "config-only" in template_creation_modes and "scaffold" not in template_creation_modes:
                app_data.creation_mode = CreationMode.CONFIG_ONLY
                await emit("template", "Auto-detected config-only mode (template does not support scaffold)")

        # Sync specs.port from template catalog if the frontend sent the default (80)
        # This ensures Tailscale Ingress, connection_info, etc. all use the correct port
        template_port = template_details.get("port")
        if template_port and app_data.specs and app_data.specs.port == 80 and template_port != 80:
            app_data.specs.port = template_port

        # Ensure workspace directory exists — use per-deploy unique subdirectory
        # to prevent race conditions when multiple deploys run concurrently.
        import uuid
        deploy_id = uuid.uuid4().hex[:8]
        deploy_workspace = f"{self.workspace}/deploy-{app_name}-{deploy_id}"
        os.makedirs(deploy_workspace, exist_ok=True)

        # Paths
        templates_repo = self._credentials.get("templates_repo", TEMPLATES_REPO)
        templates_path_clone = f"{deploy_workspace}/kaanbal-templates-clone"
        new_app_path = f"{deploy_workspace}/{app_name}"
        infra_path = f"{deploy_workspace}/infra-gitops"

        try:
            # 1. Clonar repos necesarios (templates monorepo + infra)
            await emit("clone", "Cloning template and infrastructure repositories...")
            await self._clone_repos(templates_repo, infra_path, templates_path_clone)
            await emit("clone", "Repositories cloned", "success")

            # 2. Crear repo en proveedor git (skip for config-only)
            repo_url = ""
            if app_data.creation_mode != CreationMode.CONFIG_ONLY:
                await emit("repo", f"Creating {self.provider.display_name} repository: {app_name}")
                repo_url = await self.provider.create_repo(app_name)
                await emit("repo", f"Repository created: {app_name}", "success")
            
            # 3. Preparar código de la aplicación
            if app_data.creation_mode == CreationMode.SCAFFOLD:
                await emit("scaffold", "Scaffolding application from template...")
                await self._scaffold_app(new_app_path, app_name, template_details, app_data, templates_path_clone)
                await emit("scaffold", "Application scaffolded", "success")

            elif app_data.creation_mode == CreationMode.EMPTY:
                await emit("scaffold", "Creating empty repository structure...")
                await self._create_empty_app(new_app_path, app_name)
                await emit("scaffold", "Empty repository created", "success")

            elif app_data.creation_mode == CreationMode.CONFIG_ONLY:
                 await emit("scaffold", "Config-only mode - no code generation needed", "success")

            else: # UPLOAD / COPY (Legacy)
                 # Determine template source path
                 category = template_details.get("category", "frontend")
                 template_src = os.path.join(templates_path_clone, f"templates/{category}/{template_id}")
                 
                 # Fallback support for flat structure
                 if not os.path.exists(template_src):
                     template_src = os.path.join(templates_path_clone, template_id)
                     
                 if not os.path.exists(template_src):
                     raise Exception(f"Template source not found at {template_src}")
                     
                 await self._copy_template_code(template_src, new_app_path, app_data)

            # 4. Pipeline & Dockerfile setup (if applicable)
            if app_data.creation_mode != CreationMode.CONFIG_ONLY:
                # If scaffolded or empty, we might need to inject standard pipeline/dockerfile
                await emit("pipeline", "Generating CI/CD pipeline and Dockerfile...")
                await self._setup_pipeline_and_docker(new_app_path, template_details, app_data, environments, templates_path_clone)
                await emit("pipeline", "Pipeline configured", "success")

                # 5. Push al nuevo repo (pipelines NOT enabled yet — no auto-trigger)
                await emit("push", f"Pushing code to repository...")
                await self._push_new_repo(new_app_path, repo_url, app_name)
                await emit("push", "Code pushed to repository", "success")
            
            # 6. Agregar manifests a infra-gitops
            # Locate k8s source
            await emit("k8s", "Preparing Kubernetes manifests...")
            k8s_base = template_details.get("k8s_base")
            if k8s_base:
                k8s_src = os.path.join(templates_path_clone, k8s_base)
            else:
                # Guess based on legacy structure
                category = template_details.get("category", "")
                k8s_src = os.path.join(templates_path_clone, f"templates/{category}/{template_id}/k8s")
                if not os.path.exists(k8s_src):
                    k8s_src = os.path.join(templates_path_clone, template_id, "k8s")

            if os.path.exists(k8s_src):
                await self._add_to_infra(infra_path, k8s_src, app_data, environments, spec)
                await emit("k8s", f"Kubernetes manifests added for {len(environments)} environment(s)", "success")
            else:
                await emit("k8s", "No K8s templates found - skipping manifests", "success")

            # 6b. Generate random secrets and write to Vault + patch overlays
            await emit("secrets", f"Generating secrets for {len(environments)} environment(s)...")
            env_secrets = self._generate_app_secrets_from_spec(spec, app_name, environments)
            for env in environments:
                self._patch_overlay_secrets(infra_path, app_name, env, env_secrets)
            await emit("secrets", "Secrets generated and patched into overlays", "success")

            await emit("vault", "Writing secrets to Vault...")
            vault_result = await self._write_secrets_to_vault(app_name, env_secrets, emit)
            if vault_result:
                await emit("vault", "All secrets written to Vault", "success")
            else:
                await emit("vault", "Vault not configured - secrets only in kustomize overlays", "warning")

            # 7. Push infra-gitops
            await emit("infra_push", "Pushing infrastructure changes to GitOps repo...")
            await self._push_infra(infra_path, app_name, environments)
            await emit("infra_push", "Infrastructure updated (ArgoCD will sync)", "success")

            # 7b. Create Cloudflare DNS record for public environments
            has_public = any(
                self._get_env_exposure(app_data, env) in ("public", "both")
                for env in environments
            )
            if has_public:
                public_fqdns = []
                for env in environments:
                    env_exposure = self._get_env_exposure(app_data, env)
                    if env_exposure in ("public", "both"):
                        public_fqdns.append(self._build_public_host(app_name, env, app_data))

                # Deduplicate while preserving order.
                public_fqdns = list(dict.fromkeys(public_fqdns))

                await emit("dns", f"Creating DNS records ({len(public_fqdns)}): {', '.join(public_fqdns)}...")
                dns_ok = await self._setup_cloudflare_dns(app_name, public_fqdns)
                if dns_ok:
                    await emit("dns", f"DNS records ready: {', '.join(public_fqdns)}", "success")
                else:
                    await emit("dns", "Cloudflare not configured - create DNS record manually", "warning")
            
            if app_data.creation_mode != CreationMode.CONFIG_ONLY:
                # 8. Configure CI/CD variables (BEFORE enabling CI)
                await emit("pipeline_vars", "Configuring CI/CD variables...")
                await self._configure_ci_variables(app_name)
                await emit("pipeline_vars", "CI/CD variables configured", "success")

                # 9. Enable CI/CD
                await emit("enable_pipelines", "Enabling CI/CD...")
                await self.provider.enable_ci(app_name)
                await emit("enable_pipelines", "CI/CD enabled", "success")

                # 10. Create environment branches
                await emit("branches", f"Creating environment branches: {', '.join(environments)}")
                await self._create_environment_branches(new_app_path, repo_url, environments)
                await emit("branches", "Environment branches created", "success")

                # 11. Trigger first CI run for each branch
                await emit("first_pipelines", "Triggering first CI/CD runs...")
                await self._trigger_initial_ci(app_name, environments)
                await emit("first_pipelines", "Initial CI/CD runs triggered for all environments", "success")
            
            # Scan rendered manifests for template-owned Tailscale Ingresses
            # (e.g. EMQX dashboard ingress defined in base/ingress.yaml)
            # Must happen BEFORE cleanup since infra_path is deleted
            template_ts_ingresses = self._scan_template_tailscale_ingresses(
                infra_path, app_name, environments
            )

            # Cleanup — remove entire per-deploy workspace
            self._cleanup([deploy_workspace])

            subdomain = self._build_public_host(app_name, "prod", app_data)

            # Get tailscale_dns_suffix from credentials (loaded from system_config)
            ts_dns_suffix = self._credentials.get("tailscale_dns_suffix", TAILSCALE_DNS_SUFFIX)
            vault_hostname = self._credentials.get("vault_hostname", VAULT_HOSTNAME)

            # Build connection metadata for the deployed app
            port = spec.port
            # vault_hostname may be just the hostname or full FQDN — handle both
            if vault_hostname and vault_hostname.endswith(f".{ts_dns_suffix}"):
                vault_ui_url = f"https://{vault_hostname}"
            elif vault_hostname:
                vault_ui_url = f"https://{vault_hostname}.{ts_dns_suffix}"
            else:
                vault_ui_url = f"https://vault.{self.domain}"

            # Build public URL for the app
            app_url = f"https://{subdomain}"
            is_tcp = spec.is_tcp
            tcp_port = spec.tcp_port if is_tcp else None
            tailscale_tcp_ports = spec.tailscale_tcp_ports
            connection_info = {
                "internal_dns_pattern": f"{app_name}.{{env}}.svc.cluster.local",
                "port": port,
                "secrets_name": f"{app_name}-secrets",
                "vault_path": f"secret/{{env}}/{app_name}",
                "vault_ui": vault_ui_url,
                "tailscale_dns_suffix": ts_dns_suffix,
                "is_tcp_service": is_tcp,
                "tcp_port": tcp_port,
                "per_env_exposure": {},
            }
            # Add multi-port TCP info if template has tailscale_tcp_ports
            if tailscale_tcp_ports:
                tcp_port_info = {}
                for tp in tailscale_tcp_ports:
                    pname = tp.get("name", "tcp")
                    pnum = tp.get("port")
                    tcp_port_info[pname] = {
                        "port": pnum,
                        "hostname_pattern": f"{{env}}-{app_name}-{pname}",
                        "host_pattern": f"{{env}}-{app_name}-{pname}.{ts_dns_suffix}",
                    }
                connection_info["tailscale_tcp_ports"] = tcp_port_info
            for env in environments:
                env_exposure = self._get_env_exposure(app_data, env)
                # For TCP services (Service-based exposure), Tailscale uses the annotation hostname directly
                # For web apps (Service-based exposure), hostname is set via tailscale.com/hostname annotation
                if env_exposure in ("tailscale", "both"):
                    if is_tcp:
                        ts_hostname = f"{env}-{app_name}"
                    elif tailscale_tcp_ports:
                        # Multi-port TCP app: primary TS hostname is the first TCP port's Service
                        first_tcp = tailscale_tcp_ports[0]
                        ts_hostname = f"{env}-{app_name}-{first_tcp.get('name', 'tcp')}"
                    else:
                        # Service-based exposure: hostname is set via tailscale.com/hostname annotation
                        ts_hostname = f"{env}-{app_name}"
                else:
                    ts_hostname = None

                # If deployer didn't set tailscale but template defines its own TS Ingress,
                # use the template-owned hostname (e.g. EMQX dashboard)
                if not ts_hostname and env in template_ts_ingresses:
                    ts_hostname = template_ts_ingresses[env]
                    # Override exposure type since template provides Tailscale access
                    env_exposure = "tailscale"

                env_info = {
                    "type": env_exposure,
                    "tailscale_hostname": ts_hostname,
                    "tailscale_url": f"http://{ts_hostname}.{ts_dns_suffix}" if ts_hostname else None,
                }
                # For TCP services, add direct TCP connection info
                if is_tcp and ts_hostname:
                    env_info["tailscale_tcp_host"] = f"{ts_hostname}.{ts_dns_suffix}"
                    env_info["tailscale_tcp_port"] = tcp_port
                # For multi-port TCP apps, add per-port TCP connection info
                if tailscale_tcp_ports and env_exposure in ("tailscale", "both"):
                    tcp_env_ports = {}
                    for tp in tailscale_tcp_ports:
                        pname = tp.get("name", "tcp")
                        pnum = tp.get("port")
                        tcp_env_ports[pname] = {
                            "port": pnum,
                            "tailscale_hostname": f"{env}-{app_name}-{pname}",
                            "tailscale_host": f"{env}-{app_name}-{pname}.{ts_dns_suffix}",
                        }
                    env_info["tailscale_tcp_ports"] = tcp_env_ports
                connection_info["per_env_exposure"][env] = env_info

            # Include multi-port info from template catalog so the UI can display all ports
            template_ports = template_details.get("ports")  # e.g. EMQX: 5 ports, n8n: 3 ports
            template_port_defaults = template_details.get("port_defaults")  # per-port default exposure

            return {
                "repo_url": repo_url,
                "subdomain": subdomain,
                "url": app_url,
                "environments": environments,
                "connection_info": connection_info,
                "template_ports": template_ports,
                "template_port_defaults": template_port_defaults,
                "status": "success"
            }
            
        except Exception as e:
            self._cleanup([deploy_workspace])
            raise Exception(self._sanitize_error(str(e)))
    
    async def deploy_async(self, app_id: str, app_data: AppCreate, payload: WebhookDeployRequest):
        """Deploy asincrono para background tasks"""
        db = get_db()
        try:
            result = await self.deploy(app_data)
            # Build update dict
            update_fields = {
                "status": "running",
                "repo_url": result.get("repo_url"),
                "subdomain": result.get("subdomain"),
                "url": result.get("url"),
                "connection_info": result.get("connection_info"),
                "updated_at": datetime.utcnow()
            }
            # Persist multi-port info from template so UI can render per-port links
            if result.get("template_ports"):
                update_fields["exposure.ports"] = result["template_ports"]
            if result.get("template_port_defaults"):
                update_fields["exposure.port_exposure"] = result["template_port_defaults"]
            await db.apps.update_one(
                {"_id": ObjectId(app_id)},
                {"$set": update_fields}
            )
        except Exception as e:
            await db.apps.update_one(
                {"_id": ObjectId(app_id)},
                {"$set": {
                    "status": "error",
                    "error": str(e),
                    "updated_at": datetime.utcnow()
                }}
            )
    
    async def _clone_repos(self, templates_repo: str, infra_path: str, templates_path: str):
        """Clonar templates monorepo e infra-gitops using current git provider"""
        # Use provider for authenticated clone URLs
        infra_auth_url = self.provider.get_auth_clone_url("infra-gitops")
        templates_auth_url = self.provider.get_auth_clone_url(templates_repo)
        
        # Clone infra
        if not os.path.exists(infra_path):
            try:
                subprocess.run(
                    ["git", "clone", infra_auth_url, infra_path],
                    check=True, capture_output=True
                )
            except subprocess.CalledProcessError as e:
                stderr = (e.stderr or b'').decode('utf-8', errors='replace') if isinstance(e.stderr, bytes) else str(e.stderr or '')
                raise Exception(self._sanitize_error(f"Failed to clone infra-gitops: {stderr}"))
        
        # Clone templates monorepo
        if not os.path.exists(templates_path):
            try:
                subprocess.run(
                    ["git", "clone", templates_auth_url, templates_path],
                    check=True, capture_output=True
                )
            except subprocess.CalledProcessError as e:
                stderr = (e.stderr or b'').decode('utf-8', errors='replace') if isinstance(e.stderr, bytes) else str(e.stderr or '')
                raise Exception(self._sanitize_error(f"Failed to clone templates repo: {stderr}"))
    
    async def _create_bitbucket_repo(self, app_name: str) -> str:
        """Crear repo en Bitbucket"""
        bb_workspace = self._credentials["bb_workspace"]
        bb_email = self._credentials.get("bitbucket_email", self.git_user)
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"https://api.bitbucket.org/2.0/repositories/{bb_workspace}/{app_name}",
                auth=(bb_email, self.git_token),  # Bitbucket usa email:token
                json={"scm": "git", "is_private": True}
            )
            # 200 o 409 (ya existe) son OK
            if response.status_code not in [200, 201, 409]:
                raise Exception(f"Failed to create repo: {response.text}")
        
        return f"https://bitbucket.org/{bb_workspace}/{app_name}.git"
    
    
    async def _scaffold_app(self, new_app_path: str, app_name: str, template_details: dict, app_data: AppCreate, templates_path_clone: str = None):
        """Generar app usando comando CLI (scaffold)"""
        if os.path.exists(new_app_path):
            shutil.rmtree(new_app_path)
        os.makedirs(new_app_path, exist_ok=True)
            
        scaffold_config = template_details.get("scaffold", {})
        command = scaffold_config.get("command")
        
        # Use passed templates_path_clone, fallback to old workspace path for backward compat
        if not templates_path_clone:
            templates_path_clone = f"{self.workspace}/kaanbal-templates-clone"
        
        if not command:
            # Template-files based scaffold: copy pre-built template files
            if scaffold_config.get("template_files"):
                source_dir = str(scaffold_config.get("source", "") or "").strip()

                template_src = None
                # 1) Prefer explicit scaffold.source, but NEVER allow empty (repo root)
                if source_dir:
                    candidate = os.path.join(templates_path_clone, source_dir)
                    if os.path.exists(candidate):
                        template_src = candidate

                # 2) Fallback: category-based path (catalog v4 standard)
                if not template_src:
                    category = template_details.get("category", "")
                    tpl_id = template_details.get("id", "")
                    candidate = os.path.join(templates_path_clone, f"templates/{category}/{tpl_id}")
                    if os.path.exists(candidate):
                        template_src = candidate

                if not template_src:
                    raise Exception(
                        f"Scaffold template source not found. "
                        f"Expected scaffold.source='{source_dir}' or templates/{template_details.get('category','')}/{template_details.get('id','')}"
                    )
                await self._copy_template_code(template_src, new_app_path, app_data)
                return
            raise Exception("No scaffold command defined for this template")
            
        # Render command with Jinja2 (supports conditionals like {% if use_router %}--router{% endif %})
        from jinja2 import Template
        template_config = getattr(app_data, 'template_config', {}) or {}

        # Vue-specific scaffold modes:
        # - latest: use npm create vue@latest
        # - version: use npm create vue@<requested>
        # - custom-template: copy local/custom template folder instead of running CLI
        template_id = template_details.get("id", "")
        if template_id == "vue3-spa":
            scaffold_source = str(template_config.get("scaffold_source", "latest")).strip().lower()
            if scaffold_source == "custom-template":
                custom_template_path = str(template_config.get("custom_template_path", "")).strip()
                if not custom_template_path:
                    raise Exception("custom_template_path is required when scaffold_source is 'custom-template'")

                resolved_template_path = self._resolve_custom_template_path(custom_template_path, template_details)
                await self._copy_template_code(resolved_template_path, new_app_path, app_data)
                return

            # If npm is not available in this runtime (common in the kaanbal-api Python container),
            # fall back to copying the prebuilt template from the templates monorepo.
            # This prevents scaffold failures like exit status 127.
            if shutil.which("npm") is None:
                fallback_candidates = [
                    os.path.join(templates_path_clone, "vue3-spa"),
                    os.path.join(templates_path_clone, "templates/frontend/vue3-spa"),
                ]
                fallback_src = next((p for p in fallback_candidates if os.path.exists(p)), None)
                if not fallback_src:
                    raise Exception(
                        "npm is not available for Vue scaffolding, and no fallback template was found in kaanbal-templates"
                    )
                await self._copy_template_code(fallback_src, new_app_path, app_data)
                return

            vue_cli_version = str(template_config.get("vue_cli_version", "latest")).strip()
            if scaffold_source == "version" and vue_cli_version:
                command = command.replace("vue@latest", f"vue@{vue_cli_version}")
        
        # Context for template
        ctx = {
            "APP_NAME": app_name,
            **template_config
        }
        
        try:
             # Basic variable replacement first (legacy support)
             tmplated = command.replace("{{APP_NAME}}", app_name)
             # Then Jinja2 rendering
             command_rendered = Template(tmplated).render(**ctx)
             # Basic cleanup of extra spaces
             command = " ".join(command_rendered.split())
        except Exception as e:
             logger.error(f"Failed to render scaffold command: {e}")
             # Fallback to simple replace
             command = command.replace("{{APP_NAME}}", app_name)
        
        logger_cmd = command # For logging purposes
        if self.git_token: # censor token if present
             logger_cmd = command.replace(self.git_token, "***")
        logger.info(f"Executing scaffold: {logger_cmd}")
        
        # NOTE: Some commands (npm create) are interactive. 
        # We assume the command is non-interactive or has flags to make it so.
        # e.g. "npm create vue@latest my-app -- --typescript"
        
        try:
            # We run the command in the PARENT directory of new_app_path because 
            # most scaffolds create the directory themselves.
            cwd = os.path.dirname(new_app_path)
            
            # Use shell=True to handle npm/npx/pip commands correctly on certain OS
            subprocess.run(command, cwd=cwd, shell=True, check=True)
            
            # Post commands
            post_commands = scaffold_config.get("post_commands", [])
            for cmd_tmpl in post_commands:
                # Render post commands too
                try:
                    cmd_tmpl = cmd_tmpl.replace("{{APP_NAME}}", app_name)
                    cmd = Template(cmd_tmpl).render(**ctx)
                except:
                    cmd = cmd_tmpl.replace("{{APP_NAME}}", app_name)
                    
                # If command involves changing dir to app, run it inside app dir
                if f"cd {app_name}" in cmd or f"cd {{APP_NAME}}" in cmd:
                    # Strip the cd part and run the rest inside new_app_path
                    real_cmd = cmd.replace(f"cd {app_name}", "").replace(f"cd {{APP_NAME}}", "").strip()
                    if real_cmd.startswith("&&"): real_cmd = real_cmd[2:].strip()
                    
                    if real_cmd:
                        subprocess.run(real_cmd, cwd=new_app_path, shell=True, check=True)
                else:
                    subprocess.run(cmd, cwd=cwd, shell=True, check=True)
                
        except subprocess.CalledProcessError as e:
            raise Exception(f"Scaffold command failed: {str(e)}")

    def _resolve_custom_template_path(self, custom_template_path: str, template_details: dict) -> str:
        """Resolve a custom template path for scaffold_source=custom-template."""
        normalized = custom_template_path.replace("\\", "/").strip()
        category = template_details.get("category", "")
        template_id = template_details.get("id", "")

        candidates = []
        if os.path.isabs(normalized):
            candidates.append(normalized)

        candidates.extend([
            os.path.join(self.workspace, normalized),
            os.path.join(self.workspace, "kaanbal-templates-clone", normalized),
            os.path.join(self.workspace, "kaanbal-templates-clone", "templates", category, template_id, normalized),
            os.path.join(self.workspace, "kaanbal-templates-clone", "templates", category, normalized),
        ])

        for candidate in candidates:
            if os.path.isdir(candidate):
                return candidate

        searched = "\n- ".join(candidates)
        raise Exception(
            f"Custom template path not found: {custom_template_path}. Searched:\n- {searched}"
        )

    async def _create_empty_app(self, new_app_path: str, app_name: str):
        """Crear directorio vacío para app mode=empty"""
        if os.path.exists(new_app_path):
            shutil.rmtree(new_app_path)
        os.makedirs(new_app_path, exist_ok=True)
        # Create a README
        with open(os.path.join(new_app_path, "README.md"), "w") as f:
            f.write(f"# {app_name}\n\nProject created via Kaanbal Engine.")

    async def _copy_template_code(self, template_path: str, new_app_path: str, app_data: AppCreate):
        """Copiar template y personalizar (Legacy _prepare_app_code)"""
        # Copiar
        if os.path.exists(new_app_path):
            shutil.rmtree(new_app_path)
        shutil.copytree(template_path, new_app_path)
        
        # Eliminar .git y k8s (k8s are handled separately via infra-gitops)
        git_dir = os.path.join(new_app_path, ".git")
        k8s_dir = os.path.join(new_app_path, "k8s")
        if os.path.exists(git_dir):
            shutil.rmtree(git_dir)
        if os.path.exists(k8s_dir):
            shutil.rmtree(k8s_dir)
        
        # Reemplazos
        replacements = [
            ("placeholder-app", app_data.name),
            ("example.com", self.domain),
            ("__DOMAIN__", self.domain),
        ]
        
        for root, dirs, files in os.walk(new_app_path):
            for file in files:
                filepath = os.path.join(root, file)
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    for old, new in replacements:
                        content = content.replace(old, new)
                    
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(content)
                except:
                    pass  # Skip binary files

    async def _setup_pipeline_and_docker(self, app_path: str, template_details: dict, app_data: AppCreate, environments: list, templates_repo_path: str):
        """Ensure CI/CD config file and Dockerfile exist (provider-agnostic)"""
        template_config = getattr(app_data, 'template_config', {}) or {}
        pipeline_mode = str(
            template_config.get("pipeline_mode")
            or template_details.get("pipeline_strategy")
            or "dynamic"
        ).strip().lower()
        
        # 1. CI/CD config file (bitbucket-pipelines.yml or .github/workflows/deploy.yml)
        ci_filename = self.provider.get_ci_filename()
        ci_path = os.path.join(app_path, ci_filename)
        if pipeline_mode != "template":
            await self._generate_dynamic_pipeline(app_path, app_data, environments, template_details)
        elif not os.path.exists(ci_path):
            # Check if template has a specific pipeline file defined
            tpl_pipeline_rel = template_details.get("pipeline") # e.g. "templates/frontend/vue3/pipeline.yml"
            
            if tpl_pipeline_rel and os.path.exists(os.path.join(templates_repo_path, tpl_pipeline_rel)):
                # Copy from template source (only valid for matching provider)
                shutil.copy(os.path.join(templates_repo_path, tpl_pipeline_rel), ci_path)
            else:
                # Generate dynamic pipeline
                await self._generate_dynamic_pipeline(app_path, app_data, environments, template_details)
        
        # 2. Dockerfile
        dockerfile_path = os.path.join(app_path, "Dockerfile")
        if not os.path.exists(dockerfile_path):
            tpl_docker_rel = template_details.get("dockerfile")
            
            if tpl_docker_rel and os.path.exists(os.path.join(templates_repo_path, tpl_docker_rel)):
                shutil.copy(os.path.join(templates_repo_path, tpl_docker_rel), dockerfile_path)
            else:
                 # TODO: Generate generic Dockerfile?
                 pass

    async def _push_new_repo(self, new_app_path: str, repo_url: str, app_name: str):
        """Inicializar y push nuevo repo (provider-agnostic)"""
        # Get authenticated URL from provider
        auth_repo_url = self.provider.get_auth_clone_url(app_name)
        
        commands = [
            ["git", "init"],
            ["git", "config", "user.email", f"kaanbal@{self.domain}"],
            ["git", "config", "user.name", "Kaanbal Engine"],
            ["git", "add", "."],
            ["git", "commit", "-m", f"feat: Initial commit ({app_name})"],
            ["git", "branch", "-M", "main"],
            ["git", "remote", "add", "origin", auth_repo_url],
            ["git", "push", "-u", "origin", "main", "--force"],
        ]
        
        for cmd in commands:
            result = subprocess.run(cmd, cwd=new_app_path, capture_output=True, text=True)
            if result.returncode != 0:
                error_msg = result.stderr or result.stdout or "Unknown error"
                raise Exception(self._sanitize_error(f"Git push failed: {error_msg}"))
    
    async def _add_to_infra(self, infra_path: str, k8s_source_path: str, app_data: AppCreate, environments: list, spec: TemplateSpec = None):
        """
        Agregar manifests k8s a infra-gitops.
        
        Estructura: apps/{app_name}/
                    ├── base/
                    └── overlays/
                        ├── dev/
                        ├── staging/
                        └── prod/
        
        Solo se agregan los overlays para los environments seleccionados.
        """
        app_name = app_data.name
        
        if not os.path.exists(k8s_source_path):
            return
        
        # Directorio destino único para la app
        dest_dir = os.path.join(infra_path, "apps", app_name)
        
        if os.path.exists(dest_dir):
            shutil.rmtree(dest_dir)
        os.makedirs(dest_dir, exist_ok=True)
        
        # Copiar base
        base_src = os.path.join(k8s_source_path, "base")
        base_dest = os.path.join(dest_dir, "base")
        if os.path.exists(base_src):
            shutil.copytree(base_src, base_dest)
        
        # Crear directorio overlays
        overlays_dest = os.path.join(dest_dir, "overlays")
        os.makedirs(overlays_dest, exist_ok=True)
        
        # Reemplazos base
        # NOTE: Only replace "placeholder-app" (the canonical placeholder in templates).
        # Avoid replacing template_id blindly — e.g. "mongodb" is a substring of
        # "mongo:7" image references in deployment.yaml and would corrupt them.
        dockerhub_user = self._credentials.get("dockerhub_username", "") if self._credentials else ""
        replacements = [
            ("placeholder-app", app_name),
            ("example.com", self.domain),
            ("__DOMAIN__", self.domain),
        ]
        # Replace docker hub username placeholder if it differs from the template default
        if dockerhub_user:
            replacements.append(("__DOCKER_USER__", dockerhub_user))
            if dockerhub_user != "andresbardalescalva":
                replacements.append(("andresbardalescalva", dockerhub_user))
        
        # Add replacements from template_config (optional)
        template_config = getattr(app_data, 'template_config', {}) or {}
        for k, v in template_config.items():
            replacements.append((f"{{{{{k}}}}}", str(v)))
        
        # Copiar solo los overlays de los environments seleccionados
        for env in environments:
            overlay_src = os.path.join(k8s_source_path, "overlays", env)
            overlay_dest = os.path.join(overlays_dest, env)
            
            if os.path.exists(overlay_src):
                shutil.copytree(overlay_src, overlay_dest)
            else:
                # Si no existe el overlay, crear uno básico
                os.makedirs(overlay_dest, exist_ok=True)
                self._create_basic_overlay(overlay_dest, app_name, env, app_data)
        
        # For config-only apps, strip the 'images:' section from kustomization overlays
        # so the base image (e.g. n8nio/n8n) is used directly without Docker Hub override.
        # Templates may include 'images:' for scaffold mode (pipeline updates the tag),
        # but config-only apps have no pipeline, so the tag would remain 'pending-initial-build'.
        if app_data.creation_mode == CreationMode.CONFIG_ONLY:
            for env in environments:
                kust_path = os.path.join(overlays_dest, env, "kustomization.yaml")
                if os.path.exists(kust_path):
                    with open(kust_path, 'r') as f:
                        content = f.read()
                    # Remove images: block (images: + subsequent indented lines)
                    content = re.sub(
                        r'\n# [^\n]*pipeline[^\n]*\n# [^\n]*\nimages:\n(?:[ \t]+.*\n)*',
                        '\n',
                        content,
                        flags=re.IGNORECASE
                    )
                    # Also try without comment prefix
                    content = re.sub(
                        r'\nimages:\n(?:[ \t]+.*\n)*',
                        '\n',
                        content
                    )
                    with open(kust_path, 'w') as f:
                        f.write(content)

        # Generate Tailscale exposure per env if exposure requires it
        # For database templates (mongo, postgres, redis), use L4 TCP Service
        # For multi-port apps with tailscale_tcp_ports (e.g. EMQX), use L4 TCP Service per TCP port
        # For web/API templates, use Service-based exposure (HTTP via tailscale.com/expose annotation)
        is_tcp = spec.is_tcp if spec else self._is_tcp_service(app_data.template or "")
        tailscale_tcp_ports = spec.tailscale_tcp_ports if spec else []
        public_paths = spec.public_paths if spec else []
        for env in environments:
            overlay_dest = os.path.join(overlays_dest, env)
            env_exposure = self._get_env_exposure(app_data, env)
            if env_exposure in ("tailscale", "both"):
                if is_tcp:
                    await self._generate_tailscale_tcp_service(overlay_dest, app_name, env, app_data, spec)
                elif tailscale_tcp_ports:
                    # Multi-port app with specific TCP ports needing L4 Service
                    # (e.g. EMQX MQTT port — template already handles HTTP Tailscale access via base ingress)
                    await self._generate_tailscale_tcp_services(overlay_dest, app_name, env, app_data, spec, tailscale_tcp_ports)
                else:
                    await self._generate_tailscale_ingress(overlay_dest, app_name, env, app_data, spec)
            # For "both" with public_paths defined: replace full-path nginx Ingress
            # with a path-restricted one (e.g. /webhook/*, /form/* only public, UI via Tailscale)
            if env_exposure == "both" and public_paths and not is_tcp:
                self._generate_webhook_ingress(overlay_dest, app_name, env, public_paths, app_data, spec)
            # For tailscale-only or internal web/API apps, remove the base nginx Ingress
            # (template overlays include a host-replace patch by default)
            if env_exposure in ("tailscale", "internal") and not is_tcp:
                self._remove_nginx_ingress_for_tailscale_only(overlay_dest, app_name)
            # For public (non-prod) web/API apps, ensure the overlay has a proper
            # host-replace Ingress patch. Some templates ship with $patch:delete
            # in dev/staging overlays — convert it back to a host-replace patch.
            if env_exposure in ("public", "both") and not is_tcp:
                self._ensure_nginx_ingress_for_public(overlay_dest, app_name, env, app_data)

        # Aplicar reemplazos en todos los YAMLs
        for root, dirs, files in os.walk(dest_dir):
            for file in files:
                if file.endswith('.yaml') or file.endswith('.yml'):
                    filepath = os.path.join(root, file)
                    with open(filepath, 'r') as f:
                        content = f.read()

                    for old, new in replacements:
                        content = content.replace(old, new)

                    with open(filepath, 'w') as f:
                        f.write(content)

        # Post-process: for root-domain apps, fix prod overlay host from
        # "{app}.{domain}" to "{domain}" and TLS secret accordingly.
        # Must run AFTER global replacements so we match final domain values.
        if self._is_root_domain_request(app_data) and "prod" in environments:
            prod_kust = os.path.join(overlays_dest, "prod", "kustomization.yaml")
            if os.path.exists(prod_kust):
                with open(prod_kust, 'r') as f:
                    c = f.read()
                c = c.replace(f"{app_name}.{self.domain}", self.domain)
                c = c.replace(f"tls-{app_name}", "tls-root")
                with open(prod_kust, 'w') as f:
                    f.write(c)
            # Also fix the base ingress if it contains the app-prefixed host
            base_ing = os.path.join(dest_dir, "base", "ingress.yaml")
            if os.path.exists(base_ing):
                with open(base_ing, 'r') as f:
                    c = f.read()
                # Base ingress keeps the subdomain form; prod overlay overrides it.
                # No change needed here — base is used by dev/staging overlays which
                # should keep the app-prefixed host.

        # Post-process: patch env var domains to use Tailscale hostnames
        # for environments where the public domain shouldn't be used in env vars.
        # Must run AFTER global replacements so we match the actual domain names.
        base_dest = os.path.join(dest_dir, "base")
        private_env_vars = spec.private_env_vars if spec else []
        for env in environments:
            overlay_dest = os.path.join(overlays_dest, env)
            env_exposure = self._get_env_exposure(app_data, env)
            if env_exposure == "tailscale":
                self._patch_env_domains_for_exposure(
                    overlay_dest, base_dest, app_name, env, "tailscale"
                )
            elif env_exposure == "both" and private_env_vars:
                self._patch_env_domains_for_exposure(
                    overlay_dest, base_dest, app_name, env, "both",
                    private_env_vars=private_env_vars
                )

    def _scan_template_tailscale_ingresses(self, infra_path: str, app_name: str, environments: list) -> dict:
        """
        Scan rendered manifests for Tailscale Ingress resources defined by the template
        (not generated by the deployer). Examples: EMQX dashboard ingress.
        
        Returns dict: {env: tailscale_hostname} for each env that has a template-owned TS ingress.
        The hostname follows the Tailscale Operator pattern: {namespace}-{ingressName}-ingress
        """
        import yaml as pyyaml
        result = {}
        app_dir = os.path.join(infra_path, "apps", app_name)
        if not os.path.exists(app_dir):
            return result

        # Scan base directory for Tailscale Ingress resources
        base_dir = os.path.join(app_dir, "base")
        ts_ingress_names = []
        if os.path.exists(base_dir):
            for fname in os.listdir(base_dir):
                if not (fname.endswith('.yaml') or fname.endswith('.yml')):
                    continue
                fpath = os.path.join(base_dir, fname)
                try:
                    with open(fpath, 'r') as f:
                        content = f.read()
                    for doc in pyyaml.safe_load_all(content):
                        if not doc or not isinstance(doc, dict):
                            continue
                        kind = doc.get('kind', '')
                        spec = doc.get('spec', {}) or {}
                        ingress_class = spec.get('ingressClassName', '')
                        if kind == 'Ingress' and ingress_class == 'tailscale':
                            ingress_name = doc.get('metadata', {}).get('name', '')
                            if ingress_name:
                                ts_ingress_names.append(ingress_name)
                except Exception:
                    continue

        # Also scan overlay directories for additional TS ingresses
        for env in environments:
            overlay_dir = os.path.join(app_dir, "overlays", env)
            if os.path.exists(overlay_dir):
                for fname in os.listdir(overlay_dir):
                    if not (fname.endswith('.yaml') or fname.endswith('.yml')):
                        continue
                    # Skip deployer-generated tailscale files
                    if fname in ('tailscale-ingress.yaml', 'tailscale-tcp-service.yaml', 'tailscale-svc.yaml'):
                        continue
                    fpath = os.path.join(overlay_dir, fname)
                    try:
                        with open(fpath, 'r') as f:
                            content = f.read()
                        for doc in pyyaml.safe_load_all(content):
                            if not doc or not isinstance(doc, dict):
                                continue
                            kind = doc.get('kind', '')
                            spec = doc.get('spec', {}) or {}
                            ingress_class = spec.get('ingressClassName', '')
                            if kind == 'Ingress' and ingress_class == 'tailscale':
                                ingress_name = doc.get('metadata', {}).get('name', '')
                                if ingress_name and ingress_name not in ts_ingress_names:
                                    ts_ingress_names.append(ingress_name)
                    except Exception:
                        continue

        # Map each env to the first template-owned TS ingress hostname
        # Operator pattern: {namespace}-{ingressName}-ingress
        if ts_ingress_names:
            for env in environments:
                # Use the first TS ingress found (typically the dashboard/UI)
                result[env] = f"{env}-{ts_ingress_names[0]}-ingress"

        return result

    def _get_env_exposure(self, app_data: AppCreate, env: str) -> str:
        """Get the effective exposure type for a specific environment.

        Priority order:
        1. port_exposure matrix (multi-port apps): derive env-level exposure
           from the per-port values.  If any port is 'public' AND any port is
           'tailscale' → 'both'.  If any port is 'public' → 'public'.  If any
           port is 'tailscale' → 'tailscale'.  Otherwise → 'internal'.
        2. per_env dict (single-exposure apps): direct env key lookup.
        3. exposure.type fallback.
        4. 'internal' hard default.
        """
        if app_data.exposure:
            # Multi-port path: port_exposure takes priority over per_env
            if app_data.exposure.port_exposure:
                port_modes = list(app_data.exposure.port_exposure.get(env, {}).values())
                if port_modes:
                    has_public = "public" in port_modes
                    has_tailscale = "tailscale" in port_modes
                    if has_public and has_tailscale:
                        return "both"
                    elif has_public:
                        return "public"
                    elif has_tailscale:
                        return "tailscale"
                    else:
                        return "internal"
            # Single-port path
            if app_data.exposure.per_env:
                return app_data.exposure.per_env.get(env, app_data.exposure.type or "internal")
            return app_data.exposure.type or "internal"
        return "internal"

    def _is_tcp_service(self, template_id: str) -> bool:
        """Check if the template is a raw TCP service (database) that needs L4 exposure instead of L7 Ingress."""
        tid = template_id.lower()
        return any(db in tid for db in ("mongo", "postgres", "redis", "mysql", "mariadb"))

    def _get_tcp_port(self, template_id: str, app_data: AppCreate) -> int:
        """Get the default TCP port for a database template."""
        tid = template_id.lower()
        if "mongo" in tid:
            return 27017
        elif "postgres" in tid:
            return 5432
        elif "redis" in tid:
            return 6379
        elif "mysql" in tid or "mariadb" in tid:
            return 3306
        # Fallback to app specs port
        if app_data.specs and app_data.specs.port:
            return app_data.specs.port
        return 80

    def _get_default_tags(self, template_id: str, spec: TemplateSpec = None) -> str:
        """Get default Tailscale ACL tags based on template type.
        Prefers TemplateSpec (data-driven), falls back to legacy string matching."""
        if spec:
            return spec.tailscale_tags_str
        # Legacy fallback
        tid = template_id.lower()
        tags = ["tag:k8s"]
        if any(db in tid for db in ("mongo", "postgres", "redis", "mysql", "mariadb")):
            tags.append("tag:database")
        return ",".join(tags)

    async def _get_app_tags(self, app_name: str, template_id: str, spec: TemplateSpec = None) -> str:
        """Get Tailscale tags: saved tags from MongoDB (if any), else defaults."""
        try:
            db = get_db()
            app_doc = await db.apps.find_one({"name": app_name}, {"tailscale_tags": 1})
            if app_doc and app_doc.get("tailscale_tags"):
                return ",".join(app_doc["tailscale_tags"])
        except Exception:
            pass
        return self._get_default_tags(template_id, spec)

    async def _generate_tailscale_tcp_service(self, overlay_path: str, app_name: str, env: str, app_data: AppCreate, spec: TemplateSpec = None):
        """
        Generate a Tailscale L4 TCP Service (LoadBalancer) for database apps.
        Unlike Ingress (L7/HTTPS), this exposes raw TCP on the actual port,
        making databases reachable at {hostname}.tailnet:port from any Tailnet device.
        """
        template_id = app_data.template or ""
        port = spec.tcp_port if spec else self._get_tcp_port(template_id, app_data)
        ts_hostname = f"{env}-{app_name}"
        tags = await self._get_app_tags(app_name, template_id, spec)

        svc_yaml = f"""# Tailscale L4 TCP access - generated by Kaanbal Engine
# Exposes raw TCP (port {port}) on the Tailnet for direct database connectivity
apiVersion: v1
kind: Service
metadata:
  name: {app_name}-ts
  labels:
    app: {app_name}
    software-factory.io/exposure: private-tcp
  annotations:
    argocd.argoproj.io/sync-options: ServerSideApply=true
    tailscale.com/expose: "true"
    tailscale.com/hostname: "{ts_hostname}"
    tailscale.com/tags: "{tags}"
spec:
  type: LoadBalancer
  loadBalancerClass: tailscale
  selector:
    app: {app_name}
  ports:
  - port: {port}
    targetPort: {port}
    protocol: TCP
    name: tcp
"""
        svc_path = os.path.join(overlay_path, "tailscale-svc.yaml")
        with open(svc_path, 'w') as f:
            f.write(svc_yaml)

        # Add to kustomization.yaml resources
        kustomization_path = os.path.join(overlay_path, "kustomization.yaml")
        if os.path.exists(kustomization_path):
            with open(kustomization_path, 'r') as f:
                content = f.read()
            if "tailscale-svc.yaml" not in content:
                content = re.sub(
                    r'([ \t]*)- \.\./.\./base',
                    r'\1- ../../base\n\1- tailscale-svc.yaml',
                    content,
                    count=1
                )
                with open(kustomization_path, 'w') as f:
                    f.write(content)

    async def _generate_tailscale_tcp_services(self, overlay_path: str, app_name: str, env: str,
                                                app_data: AppCreate, spec: TemplateSpec,
                                                tcp_ports: list[dict]):
        """
        Generate Tailscale L4 TCP Service(s) for specific ports of a multi-port app.

        For apps like EMQX that have both TCP (MQTT 1883) and HTTP (Dashboard 18083) ports,
        the template base already handles HTTP Tailscale access (dashboard Ingress). This method
        creates L4 LoadBalancer Services only for the raw TCP ports that can't use L7 Ingress.

        Each TCP port gets its own Service with hostname pattern: {env}-{app_name}-{port_name}
        e.g. dev-emqxtest-mqtt → reachable at dev-emqxtest-mqtt.tailnet:1883
        """
        template_id = app_data.template or ""
        tags = await self._get_app_tags(app_name, template_id, spec)

        documents = []
        for port_def in tcp_ports:
            port_name = port_def.get("name", "tcp")
            port_num = port_def.get("port", 1883)
            ts_hostname = f"{env}-{app_name}-{port_name}"

            svc_yaml = f"""# Tailscale L4 TCP access for {port_name} - generated by Kaanbal Engine
# Exposes raw TCP (port {port_num}) on the Tailnet for direct {port_name} connectivity
apiVersion: v1
kind: Service
metadata:
  name: {app_name}-{port_name}-ts
  labels:
    app: {app_name}
    software-factory.io/exposure: private-tcp
  annotations:
    argocd.argoproj.io/sync-options: ServerSideApply=true
    tailscale.com/expose: "true"
    tailscale.com/hostname: "{ts_hostname}"
    tailscale.com/tags: "{tags}"
spec:
  type: LoadBalancer
  loadBalancerClass: tailscale
  selector:
    app: {app_name}
  ports:
  - port: {port_num}
    targetPort: {port_num}
    protocol: TCP
    name: {port_name}"""
            documents.append(svc_yaml)

        content = "\n---\n".join(documents) + "\n"
        # Use tailscale-ingress.yaml filename for consistency with kustomization references
        svc_path = os.path.join(overlay_path, "tailscale-ingress.yaml")
        with open(svc_path, 'w') as f:
            f.write(content)

        # Add to kustomization.yaml resources
        kustomization_path = os.path.join(overlay_path, "kustomization.yaml")
        if os.path.exists(kustomization_path):
            with open(kustomization_path, 'r') as f:
                kust_content = f.read()
            if "tailscale-ingress.yaml" not in kust_content:
                kust_content = re.sub(
                    r'([ \t]*)- \.\./.\./base',
                    r'\1- ../../base\n\1- tailscale-ingress.yaml',
                    kust_content,
                    count=1
                )
                with open(kustomization_path, 'w') as f:
                    f.write(kust_content)

    async def _generate_tailscale_ingress(self, overlay_path: str, app_name: str, env: str, app_data: AppCreate, spec: TemplateSpec = None):
        """
        Generate a Tailscale Service-based exposure for web apps.
        Uses a K8s Service with tailscale.com/expose annotation (L4 proxy),
        which works without HTTPS certificate support on the Tailscale account.
        The Tailscale Operator creates a proxy pod that forwards HTTP traffic.
        Accessible at http://{env}-{app_name}.{tailnet_dns_suffix}
        """
        port = app_data.specs.port if app_data.specs and app_data.specs.port else 80
        ts_hostname = f"{env}-{app_name}"
        tags = await self._get_app_tags(app_name, app_data.template or '', spec)

        svc_yaml = f"""# Tailscale private access (Service-based) - generated by Kaanbal Engine
# Accessible at http://{ts_hostname}.{{tailnet_suffix}}
apiVersion: v1
kind: Service
metadata:
  name: {app_name}-ts
  labels:
    app: {app_name}
    software-factory.io/exposure: private
  annotations:
    argocd.argoproj.io/sync-options: ServerSideApply=true
    tailscale.com/expose: "true"
    tailscale.com/hostname: "{ts_hostname}"
    tailscale.com/tags: "{tags}"
spec:
  type: ClusterIP
  selector:
    app: {app_name}
  ports:
  - port: 80
    targetPort: {port}
    protocol: TCP
    name: http
"""
        svc_path = os.path.join(overlay_path, "tailscale-svc.yaml")
        with open(svc_path, 'w') as f:
            f.write(svc_yaml)

        # Add to kustomization.yaml resources
        kustomization_path = os.path.join(overlay_path, "kustomization.yaml")
        if os.path.exists(kustomization_path):
            with open(kustomization_path, 'r') as f:
                content = f.read()
            if "tailscale-svc.yaml" not in content:
                content = re.sub(
                    r'([ \t]*)- \.\./.\./base',
                    r'\1- ../../base\n\1- tailscale-svc.yaml',
                    content,
                    count=1
                )
                with open(kustomization_path, 'w') as f:
                    f.write(content)

    def _remove_nginx_ingress_for_tailscale_only(self, overlay_path: str, app_name: str):
        """For tailscale-only web/API apps: replace nginx Ingress host-replace
        patch with $patch:delete so the base Ingress is completely removed.

        Template overlays ship with an Ingress host-replace patch by default.
        When exposure=tailscale we must convert that into a strategic-merge
        delete so nginx does not create a duplicate host rule.

        Runs BEFORE global placeholder replacements, so matches template
        placeholder names too (e.g. 'placeholder-app').
        """
        kust_path = os.path.join(overlay_path, "kustomization.yaml")
        if not os.path.exists(kust_path):
            return

        with open(kust_path, 'r') as f:
            content = f.read()

        # Match the Ingress target+patch block (handles any indent / app name)
        pattern = re.compile(
            r'^([ ]*)- target:\s*\n'        # "- target:" with captured indent
            r'\s+kind:\s*Ingress\s*\n'       # kind: Ingress
            r'\s+name:\s*([\w-]+)\s*\n'      # name: <name>
            r'\s+patch:\s*\|-\s*\n'          # patch: |-
            r'(?:[ \t]+.*\n)*',              # patch body (indented lines)
            re.MULTILINE
        )

        match = pattern.search(content)
        if not match:
            logger.debug(f"No Ingress patch found in {kust_path} — skipping tailscale-only conversion")
            return

        indent = match.group(1)   # e.g. "  " (2 spaces)
        name = match.group(2)     # e.g. "placeholder-app"

        replacement = (
            f"{indent}# Tailscale-only — remove base nginx Ingress to avoid host conflicts\n"
            f"{indent}- target:\n"
            f"{indent}    kind: Ingress\n"
            f"{indent}    name: {name}\n"
            f"{indent}  patch: |-\n"
            f"{indent}    $patch: delete\n"
            f"{indent}    apiVersion: networking.k8s.io/v1\n"
            f"{indent}    kind: Ingress\n"
            f"{indent}    metadata:\n"
            f"{indent}      name: {name}\n"
        )

        content = content[:match.start()] + replacement + content[match.end():]

        with open(kust_path, 'w') as f:
            f.write(content)
        logger.info(f"Converted Ingress patch to $patch:delete in {kust_path} (tailscale-only)")

    def _ensure_nginx_ingress_for_public(self, overlay_path: str, app_name: str, env: str, app_data: Optional[AppCreate] = None):
        """For public web/API apps: ensure the overlay has a proper host-replace
        Ingress patch. Some templates ship with $patch:delete in non-prod overlays
        (e.g. vue3-spa assumes dev/staging are tailscale-only). When the user
        selects public exposure, convert the $patch:delete back to a host-replace.

        Runs BEFORE global placeholder replacements, so matches template
        placeholder names (e.g. 'placeholder-app') as well as the real app name.
        """
        kust_path = os.path.join(overlay_path, "kustomization.yaml")
        if not os.path.exists(kust_path):
            return

        with open(kust_path, 'r') as f:
            content = f.read()

        # Only act if we find a $patch: delete targeting an Ingress
        pattern = re.compile(
            r'^([ ]*)(?:#[^\n]*\n\s*)?- target:\s*\n'  # "- target:" with optional comment
            r'\s+kind:\s*Ingress\s*\n'                   # kind: Ingress
            r'\s+name:\s*([\w-]+)\s*\n'                  # name: <name>
            r'\s+patch:\s*\|-\s*\n'                      # patch: |-
            r'((?:[ \t]+.*\n)*)',                         # patch body
            re.MULTILINE
        )

        match = pattern.search(content)
        if not match:
            return

        patch_body = match.group(3)
        if "$patch: delete" not in patch_body and "$patch:delete" not in patch_body:
            # Already a host-replace patch — nothing to do (root-domain fixup
            # happens after global replacements in _setup_infra)
            return

        indent = match.group(1)
        name = match.group(2)

        host_tokenized = self._build_public_host_tokenized(app_name, env, app_data)
        use_root_domain = bool(app_data and self._is_root_domain_request(app_data) and env == "prod")
        tls_suffix = "root" if use_root_domain else (app_name if env == "prod" else f"{env}-{app_name}")

        # Replace $patch:delete with a proper host-replace JSON patch
        replacement = (
            f"{indent}- target:\n"
            f"{indent}    kind: Ingress\n"
            f"{indent}    name: {name}\n"
            f"{indent}  patch: |-\n"
            f"{indent}    - op: replace\n"
            f"{indent}      path: /spec/rules/0/host\n"
            f"{indent}      value: {host_tokenized}\n"
            f"{indent}    - op: replace\n"
            f"{indent}      path: /spec/tls/0/hosts/0\n"
            f"{indent}      value: {host_tokenized}\n"
            f"{indent}    - op: replace\n"
            f"{indent}      path: /spec/tls/0/secretName\n"
            f"{indent}      value: tls-{tls_suffix}\n"
        )

        content = content[:match.start()] + replacement + content[match.end():]

        with open(kust_path, 'w') as f:
            f.write(content)
        logger.info(f"Restored Ingress host-replace patch in {kust_path} (public exposure for {env})")

    def _generate_webhook_ingress(self, overlay_path: str, app_name: str, env: str,
                                   public_paths: list[str], app_data: AppCreate,
                                   spec: TemplateSpec = None):
        """Generate a path-restricted public nginx Ingress for 'both' exposure.

        When a template defines public_paths (e.g. ["/webhook/*", "/form/*"]),
        only those paths are exposed publicly via nginx. The full UI remains
        accessible only via the Tailscale Ingress.

        Steps:
        1. Delete the base full-path nginx Ingress via kustomize $patch:delete
        2. Create a new webhook-ingress.yaml with only the specified paths
        3. Register it as a kustomize resource
        """
        port = app_data.specs.port if app_data.specs and app_data.specs.port else 80

        host = self._build_public_host(app_name, env, app_data)

        # Convert glob paths to nginx Ingress paths
        # /webhook/* → /webhook, /webhook-test/* → /webhook-test, /form/* → /form
        ingress_paths = []
        for p in public_paths:
            # Strip trailing /* or * for Prefix matching
            clean = p.rstrip("*").rstrip("/")
            if not clean:
                clean = "/"
            ingress_paths.append(clean)
        # Deduplicate while preserving order
        seen = set()
        unique_paths = []
        for p in ingress_paths:
            if p not in seen:
                seen.add(p)
                unique_paths.append(p)

        # Build path rules YAML
        path_rules = ""
        for p in unique_paths:
            path_rules += f"""      - path: {p}
        pathType: Prefix
        backend:
          service:
            name: {app_name}
            port:
              number: {port}
"""

        ingress_yaml = f"""# Public webhook/API ingress - generated by Kaanbal Engine
# Only exposes specific paths publicly. Full UI access via Tailscale VPN.
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {app_name}-webhook
  labels:
    app: {app_name}
    software-factory.io/exposure: public-paths
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
    nginx.ingress.kubernetes.io/proxy-body-size: "100m"
    nginx.ingress.kubernetes.io/proxy-read-timeout: "3600"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "3600"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - {host}
    secretName: tls-{env}-{app_name}-webhook
  rules:
  - host: {host}
    http:
      paths:
{path_rules}"""

        # Write the webhook ingress file
        ingress_path = os.path.join(overlay_path, "webhook-ingress.yaml")
        with open(ingress_path, 'w') as f:
            f.write(ingress_yaml)

        # Remove the base full-path nginx Ingress (replace patch with $patch:delete)
        self._remove_nginx_ingress_for_tailscale_only(overlay_path, app_name)

        # Add webhook-ingress.yaml to kustomization.yaml resources
        kustomization_path = os.path.join(overlay_path, "kustomization.yaml")
        if os.path.exists(kustomization_path):
            with open(kustomization_path, 'r') as f:
                content = f.read()
            if "webhook-ingress.yaml" not in content:
                content = re.sub(
                    r'([ \t]*)- \.\./\.\./base',
                    r'\1- ../../base\n\1- webhook-ingress.yaml',
                    content,
                    count=1
                )
                with open(kustomization_path, 'w') as f:
                    f.write(content)

        logger.info(f"Generated webhook-ingress.yaml for {app_name}/{env} with paths: {unique_paths}")

    def _patch_env_domains_for_exposure(self, overlay_path: str, base_path: str,
                                         app_name: str, env: str,
                                         env_exposure: str,
                                         private_env_vars: list = None):
        """Post-process overlay env var patches to use Tailscale hostnames.

        After global placeholder replacements, overlay kustomization.yaml env var
        patches reference the public domain (e.g., staging-app.domain.com).  For
        tailscale-only envs those should point to the Tailscale FQDN.  For "both"
        envs with private_env_vars, only the specified env vars get patched.

        Args:
            overlay_path: Path to the overlay directory (e.g., .../overlays/staging)
            base_path: Path to the base k8s directory (e.g., .../base)
            app_name: Actual app name after placeholder replacement
            env: Environment name (dev/staging/prod)
            env_exposure: "tailscale" or "both"
            private_env_vars: For "both" mode — env var names to convert to Tailscale
        """
        import yaml as pyyaml

        ts_suffix = self._credentials.get("tailscale_dns_suffix", TAILSCALE_DNS_SUFFIX)
        ts_fqdn = f"{env}-{app_name}.{ts_suffix}"

        # Compute public domain for this environment
        if env == "prod":
            public_domain = f"{app_name}.{self.domain}"
        elif env == "staging":
            public_domain = f"staging-{app_name}.{self.domain}"
        else:
            public_domain = f"{env}-{app_name}.{self.domain}"

        kust_path = os.path.join(overlay_path, "kustomization.yaml")
        if not os.path.exists(kust_path):
            return

        with open(kust_path, 'r') as f:
            content = f.read()

        modified = False

        if env_exposure == "tailscale":
            # Tailscale-only: replace ALL occurrences of public domain with Tailscale FQDN.
            # At this point the Ingress patches are already $patch:delete, so only env var
            # values and misc references remain.
            if public_domain in content:
                content = content.replace(public_domain, ts_fqdn)
                modified = True

            # Also handle env vars that come from the base deployment (not overridden
            # in the overlay). Scan the base deployment for domain-referencing env vars
            # and add patches for any that the overlay doesn't already cover.
            deploy_path = os.path.join(base_path, "deployment.yaml")
            if os.path.exists(deploy_path):
                with open(deploy_path, 'r') as f:
                    deploy_data = pyyaml.safe_load(f)
                containers = (deploy_data or {}).get("spec", {}).get("template", {}).get("spec", {}).get("containers", [])
                if containers:
                    env_vars = containers[0].get("env", [])
                    missing_patches = []
                    for idx, var in enumerate(env_vars):
                        value = str(var.get("value", ""))
                        env_path = f"/spec/template/spec/containers/0/env/{idx}/value"
                        if self.domain in value and env_path not in content:
                            new_value = value.replace(public_domain, ts_fqdn)
                            # Also replace the base prod domain (no env prefix)
                            new_value = new_value.replace(f"{app_name}.{self.domain}", ts_fqdn)
                            missing_patches.append(f"    - op: replace\n      path: {env_path}\n      value: \"{new_value}\"")
                    if missing_patches:
                        # Append to the Deployment patch block
                        deploy_patch_re = re.compile(
                            r'(- target:\s*\n\s+kind:\s*Deployment\s*\n\s+name:\s*[\w-]+\s*\n\s+patch:\s*\|-\s*\n(?:[ \t]+.*\n)*)',
                            re.MULTILINE
                        )
                        match = deploy_patch_re.search(content)
                        if match:
                            insert_pos = match.end()
                            extra = "\n".join(missing_patches) + "\n"
                            content = content[:insert_pos] + extra + content[insert_pos:]
                            modified = True

        elif env_exposure == "both" and private_env_vars:
            # Only patch specific env vars to use Tailscale FQDN.
            # These are typically the editor/UI URL env vars.
            deploy_path = os.path.join(base_path, "deployment.yaml")
            if not os.path.exists(deploy_path):
                return
            with open(deploy_path, 'r') as f:
                deploy_data = pyyaml.safe_load(f)
            containers = (deploy_data or {}).get("spec", {}).get("template", {}).get("spec", {}).get("containers", [])
            if not containers:
                return
            env_vars = containers[0].get("env", [])

            new_ops = []
            for idx, var in enumerate(env_vars):
                name = var.get("name", "")
                value = str(var.get("value", ""))
                if name not in private_env_vars:
                    continue
                if self.domain not in value:
                    continue
                env_path = f"/spec/template/spec/containers/0/env/{idx}/value"
                # Check if overlay already patches this env var
                if env_path in content:
                    # Replace the domain in the existing patch value
                    pattern = re.compile(
                        rf'(path:\s*{re.escape(env_path)}\s*\n\s+value:\s*"?)([^"\n]+)("?)',
                        re.MULTILINE
                    )
                    m = pattern.search(content)
                    if m:
                        old_val = m.group(2)
                        new_val = old_val.replace(public_domain, ts_fqdn)
                        if new_val == old_val:
                            # Try replacing base domain (prod has no prefix)
                            new_val = old_val.replace(f"{app_name}.{self.domain}", ts_fqdn)
                        content = content[:m.start(2)] + new_val + content[m.end(2):]
                        modified = True
                else:
                    # Need to add a new patch op
                    new_value = value.replace(f"{app_name}.{self.domain}", ts_fqdn)
                    new_ops.append(f"    - op: replace\n      path: {env_path}\n      value: \"{new_value}\"")

            if new_ops:
                deploy_patch_re = re.compile(
                    r'(- target:\s*\n\s+kind:\s*Deployment\s*\n\s+name:\s*[\w-]+\s*\n\s+patch:\s*\|-\s*\n(?:[ \t]+.*\n)*)',
                    re.MULTILINE
                )
                match = deploy_patch_re.search(content)
                if match:
                    insert_pos = match.end()
                    extra = "\n".join(new_ops) + "\n"
                    content = content[:insert_pos] + extra + content[insert_pos:]
                    modified = True

        if modified:
            with open(kust_path, 'w') as f:
                f.write(content)
            logger.info(f"Patched env var domains for {app_name}/{env} (exposure={env_exposure}, tailscale_fqdn={ts_fqdn})")

    def _generate_password(self, length: int = 24) -> str:
        """Generate a cryptographically secure random password"""
        alphabet = string.ascii_letters + string.digits
        return ''.join(secrets_module.choice(alphabet) for _ in range(length))

    def _generate_app_secrets_from_spec(self, spec: TemplateSpec, app_name: str, environments: list) -> dict:
        """
        Generate random credentials per environment using TemplateSpec (data-driven).
        Reads secret definitions from catalog.json — no hardcoded template checks.
        Returns: {env: {key: value, ...}, ...}
        """
        env_secrets = {}
        for env in environments:
            env_secrets[env] = spec.generate_secrets(env, app_name)
        return env_secrets

    def _generate_app_secrets(self, app_name: str, template_id: str, environments: list) -> dict:
        """
        LEGACY: Generate random credentials per environment for an app.
        Kept for backward compatibility with delete_app and other callers.
        New deploys use _generate_app_secrets_from_spec().
        Returns: {env: {key: value, ...}, ...}
        """
        env_secrets = {}
        for env in environments:
            if "mongo" in template_id.lower():
                prefix = env[:3]
                env_secrets[env] = {
                    "MONGO_USER": f"{prefix}admin",
                    "MONGO_PASSWORD": self._generate_password(),
                }
            elif "postgres" in template_id.lower():
                prefix = env[:3]
                env_secrets[env] = {
                    "POSTGRES_USER": f"{prefix}admin",
                    "POSTGRES_PASSWORD": self._generate_password(),
                    "POSTGRES_DB": app_name.replace("-", "_"),
                }
            elif "redis" in template_id.lower():
                env_secrets[env] = {
                    "REDIS_PASSWORD": self._generate_password(),
                }
            elif "mysql" in template_id.lower() or "mariadb" in template_id.lower():
                prefix = env[:3]
                env_secrets[env] = {
                    "MYSQL_ROOT_PASSWORD": self._generate_password(),
                    "MYSQL_USER": f"{prefix}admin",
                    "MYSQL_PASSWORD": self._generate_password(),
                    "MYSQL_DATABASE": app_name.replace("-", "_"),
                }
            elif "n8n" in template_id.lower():
                env_secrets[env] = {
                    "N8N_ENCRYPTION_KEY": self._generate_password(),
                    "APP_SECRET": self._generate_password(),
                }
            elif "emqx" in template_id.lower():
                env_secrets[env] = {
                    "EMQX_DASHBOARD__DEFAULT_PASSWORD": self._generate_password(),
                }
            else:
                env_secrets[env] = {
                    "APP_SECRET": self._generate_password(),
                }
        return env_secrets

    async def _write_secrets_to_vault(self, app_name: str, env_secrets: dict, emit=None):
        """
        Write generated secrets to Vault KV v2 engine.
        Path: secret/data/{env}/{app_name}
        """
        vault_addr = self._credentials.get("vault_addr", "")
        vault_token = self._credentials.get("vault_token", "")

        if not vault_addr or not vault_token:
            logger.warning("Vault not configured (vault_addr/vault_token missing) - skipping Vault write")
            return False

        wrote_any = False
        async with httpx.AsyncClient(verify=False, timeout=10) as client:
            for env, secrets_data in env_secrets.items():
                vault_path = f"{vault_addr}/v1/secret/data/{env}/{app_name}"
                try:
                    if emit:
                        await emit("vault", f"Writing secrets to Vault ({env})...")
                    resp = await client.post(
                        vault_path,
                        headers={"X-Vault-Token": vault_token},
                        json={"data": secrets_data}
                    )
                    if resp.status_code in (200, 204):
                        logger.info(f"Wrote secrets to Vault: secret/{env}/{app_name}")
                        if emit:
                            keys = ", ".join(secrets_data.keys())
                            await emit("vault", f"Vault ({env}): {keys} written", "success")
                        wrote_any = True
                    else:
                        logger.warning(f"Vault write failed for {env}/{app_name}: HTTP {resp.status_code} - {resp.text}")
                        if emit:
                            await emit("vault", f"Vault ({env}): write failed (HTTP {resp.status_code})", "error")
                except Exception as e:
                    logger.warning(f"Vault write error for {env}/{app_name}: {e}")
                    if emit:
                        await emit("vault", f"Vault ({env}): connection error", "error")

        return wrote_any

    def _patch_overlay_secrets(self, infra_path: str, app_name: str, env: str, env_secrets: dict):
        """
        Patch kustomization.yaml in an overlay to use generated passwords
        instead of hardcoded template values.

        Uses 'behavior: replace' only when the base kustomization already
        defines a Secret resource with the same name (to avoid kustomize
        name-collision errors).  Otherwise creates the secret fresh.
        """
        overlay_kust = os.path.join(infra_path, "apps", app_name, "overlays", env, "kustomization.yaml")
        if not os.path.exists(overlay_kust):
            return

        with open(overlay_kust, 'r') as f:
            content = f.read()

        secrets_data = env_secrets.get(env, {})
        if not secrets_data:
            return

        # Determine if the base kustomization includes a secret.yaml resource.
        # If it does, kustomize already defines a Secret with the app name, and
        # the overlay secretGenerator must use 'behavior: replace' to avoid
        # "already registered id" errors.
        secret_name = f"{app_name}-secrets"
        base_has_secret = False
        base_kust_path = os.path.join(infra_path, "apps", app_name, "base", "kustomization.yaml")
        if os.path.exists(base_kust_path):
            with open(base_kust_path, 'r') as bf:
                base_content = bf.read()
            # Check if secret.yaml is listed in resources
            if 'secret.yaml' in base_content:
                base_has_secret = True

        behavior_line = "    behavior: replace\n" if base_has_secret else ""

        # Check if secretGenerator already exists
        if "secretGenerator:" in content:
            # Replace existing literals with new generated values
            lines = content.split('\n')
            new_lines = []
            in_literals = False
            literals_done = False
            for line in lines:
                if 'literals:' in line and not literals_done:
                    in_literals = True
                    new_lines.append(line)
                    # Insert new generated literals
                    for key, val in secrets_data.items():
                        new_lines.append(f'      - {key}={val}')
                    literals_done = True
                    continue
                if in_literals:
                    # Skip old literal lines (starting with spaces + -)
                    stripped = line.strip()
                    if stripped.startswith('- ') and '=' in stripped:
                        continue  # Skip old literal
                    else:
                        in_literals = False
                        new_lines.append(line)
                else:
                    new_lines.append(line)

            content = '\n'.join(new_lines)
        else:
            # No secretGenerator exists - add one
            literals = '\n'.join([f'      - {k}={v}' for k, v in secrets_data.items()])
            content += f"""
# Generated secrets by Kaanbal Engine
secretGenerator:
  - name: {secret_name}
{behavior_line}    literals:
{literals}
"""

        with open(overlay_kust, 'w') as f:
            f.write(content)

    def _create_basic_overlay(self, overlay_path: str, app_name: str, env: str, app_data: AppCreate = None):
        """Crear un overlay básico si no existe en el template"""
        # Determinar prefijo de subdominio
        if env == "prod":
            subdomain = app_name
            replicas = 2
        elif env == "staging":
            subdomain = f"staging-{app_name}"
            replicas = 1
        else:  # dev
            subdomain = f"dev-{app_name}"
            replicas = 1

        # Override replicas if specified
        if app_data and app_data.specs:
             # Use user value for replicas (applied to all envs or custom logic could go here)
             replicas = app_data.specs.replicas

        is_config_only = app_data and app_data.creation_mode == CreationMode.CONFIG_ONLY

        # Build kustomization sections
        images_section = ""
        if not is_config_only:
            dockerhub_user = self._credentials.get("dockerhub_username", "") if self._credentials else ""
            images_section = f"""
images:
  - name: nginx:stable-alpine
    newName: {dockerhub_user}/{app_name}
    newTag: pending-initial-build
"""

        ingress_patch = ""
        if not is_config_only:
            env_exposure = self._get_env_exposure(app_data, env) if app_data else "public"
            if env == "prod":
                # Prod: patch the base nginx Ingress with the correct host
                ingress_patch = f"""
- target:
    kind: Ingress
    name: {app_name}
  patch: |-
    - op: replace
      path: /spec/rules/0/host
      value: {subdomain}.{self.domain}
    - op: replace
      path: /spec/tls/0/hosts/0
      value: {subdomain}.{self.domain}
    - op: replace
      path: /spec/tls/0/secretName
      value: tls-{subdomain}"""
            elif env_exposure == "both":
                # Both: keep the nginx Ingress with env-prefixed host + Tailscale Ingress added separately
                ingress_patch = f"""
- target:
    kind: Ingress
    name: {app_name}
  patch: |-
    - op: replace
      path: /spec/rules/0/host
      value: {subdomain}.{self.domain}
    - op: replace
      path: /spec/tls/0/hosts/0
      value: {subdomain}.{self.domain}
    - op: replace
      path: /spec/tls/0/secretName
      value: tls-{subdomain}"""
            elif env_exposure == "public":
                # Public only (no Tailscale): keep the nginx Ingress with env-prefixed host
                ingress_patch = f"""
- target:
    kind: Ingress
    name: {app_name}
  patch: |-
    - op: replace
      path: /spec/rules/0/host
      value: {subdomain}.{self.domain}
    - op: replace
      path: /spec/tls/0/hosts/0
      value: {subdomain}.{self.domain}
    - op: replace
      path: /spec/tls/0/secretName
      value: tls-{subdomain}"""
            else:
                # Tailscale-only: remove the base nginx Ingress
                # (nginx rejects duplicate host/path across namespaces)
                ingress_patch = f"""
# {env.capitalize()} uses Tailscale only \u2014 remove base nginx Ingress to avoid host conflicts
- target:
    kind: Ingress
    name: {app_name}
  patch: |-
    $patch: delete
    apiVersion: networking.k8s.io/v1
    kind: Ingress
    metadata:
      name: {app_name}"""

        kustomization = f"""apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
- ../../base
namespace: {env}

commonLabels:
  environment: {env}
{images_section}
patches:
- target:
    kind: Deployment
    name: {app_name}
  patch: |-
    - op: replace
      path: /spec/replicas
      value: {replicas}
{ingress_patch}
"""
        with open(os.path.join(overlay_path, "kustomization.yaml"), 'w') as f:
            f.write(kustomization)
    
    async def _push_infra(self, infra_path: str, app_name: str, environments: list):
        """Commit y push cambios a infra-gitops"""
        envs_str = ", ".join(environments)
        
        # Config commands — safe to ignore errors
        for cmd in [
            ["git", "config", "user.email", f"kaanbal@{self.domain}"],
            ["git", "config", "user.name", "Kaanbal Engine"],
        ]:
            subprocess.run(cmd, cwd=infra_path, capture_output=True)
        
        # Stage all changes
        subprocess.run(["git", "add", "."], cwd=infra_path, check=True, capture_output=True)
        
        # Commit — may fail if no changes (that's OK)
        commit_result = subprocess.run(
            ["git", "commit", "-m", f"feat: Add {app_name} to apps ({envs_str})"],
            cwd=infra_path, capture_output=True, text=True
        )
        if commit_result.returncode != 0:
            # "nothing to commit" is fine, anything else is a real error
            if "nothing to commit" in (commit_result.stdout + commit_result.stderr):
                logger.info(f"No infra changes to commit for {app_name}")
                return
            raise Exception(f"Git commit failed for infra-gitops: {self._sanitize_error(commit_result.stderr or commit_result.stdout)}")
        
        # Pull with rebase to avoid conflicts with CD pipeline pushes
        pull_result = subprocess.run(
            ["git", "pull", "--rebase", "origin", "main"],
            cwd=infra_path, capture_output=True, text=True
        )
        if pull_result.returncode != 0:
            logger.warning(f"Git pull --rebase failed for infra-gitops: {pull_result.stderr}")
            # Try without rebase
            subprocess.run(
                ["git", "rebase", "--abort"],
                cwd=infra_path, capture_output=True
            )
        
        # Push — THIS MUST SUCCEED
        push_result = subprocess.run(
            ["git", "push", "origin", "main"],
            cwd=infra_path, capture_output=True, text=True
        )
        if push_result.returncode != 0:
            error_msg = push_result.stderr or push_result.stdout or "Unknown push error"
            raise Exception(f"Failed to push infra-gitops: {self._sanitize_error(error_msg)}")

    async def _setup_cloudflare_dns(self, app_name: str, fqdns: Optional[list[str]] = None) -> bool:
        """Create a Cloudflare DNS CNAME record for a public app.
        
        Uses the existing tunnel (wildcard ingress rule routes *.domain to nginx).
        Only needs the DNS record so the domain resolves.
        Returns True if record was created, False if Cloudflare is not configured.
        """
        cf_token = self._credentials.get("cloudflare_token", "")
        cf_account = self._credentials.get("cloudflare_account_id", "")
        cf_tunnel_id = self._credentials.get("cloudflare_tunnel_id", "")
        cf_zone_id = self._credentials.get("cloudflare_zone_id", "")

        if not cf_token or not cf_account:
            logger.warning("Cloudflare not configured - skipping DNS record creation")
            return False

        cf_api = "https://api.cloudflare.com/client/v4"
        headers = {
            "Authorization": f"Bearer {cf_token}",
            "Content-Type": "application/json",
        }
        records = fqdns if fqdns else [f"{app_name}.{self.domain}"]

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                # Resolve zone_id if not cached
                if not cf_zone_id:
                    zone_resp = await client.get(
                        f"{cf_api}/zones?name={self.domain}&status=active",
                        headers=headers,
                    )
                    zones = zone_resp.json().get("result", [])
                    if zones:
                        cf_zone_id = zones[0]["id"]
                        # Cache zone_id in MongoDB for future deploys
                        db = get_db()
                        await db.system_config.update_one(
                            {"_id": "main"},
                            {"$set": {"cloudflare_zone_id": cf_zone_id}},
                        )
                        self._credentials["cloudflare_zone_id"] = cf_zone_id
                    else:
                        logger.warning(f"No Cloudflare zone found for {self.domain}")
                        return False

                # Resolve tunnel_id if not cached
                if not cf_tunnel_id:
                    tunnels_resp = await client.get(
                        f"{cf_api}/accounts/{cf_account}/cfd_tunnel?is_deleted=false",
                        headers=headers,
                    )
                    tunnels = tunnels_resp.json().get("result", [])
                    if tunnels:
                        cf_tunnel_id = tunnels[0]["id"]
                        db = get_db()
                        await db.system_config.update_one(
                            {"_id": "main"},
                            {"$set": {"cloudflare_tunnel_id": cf_tunnel_id}},
                        )
                        self._credentials["cloudflare_tunnel_id"] = cf_tunnel_id
                    else:
                        logger.warning("No Cloudflare tunnel found")
                        return False

                cname_target = f"{cf_tunnel_id}.cfargotunnel.com"

                for fqdn in records:
                    # Check if DNS record already exists
                    existing_resp = await client.get(
                        f"{cf_api}/zones/{cf_zone_id}/dns_records?type=CNAME&name={fqdn}",
                        headers=headers,
                    )
                    existing = existing_resp.json().get("result", [])

                    if existing:
                        # Update existing record
                        await client.put(
                            f"{cf_api}/zones/{cf_zone_id}/dns_records/{existing[0]['id']}",
                            headers=headers,
                            json={"type": "CNAME", "name": fqdn, "content": cname_target, "proxied": True},
                        )
                        logger.info(f"Updated Cloudflare DNS: {fqdn} -> {cname_target}")
                    else:
                        # Create new record
                        create_resp = await client.post(
                            f"{cf_api}/zones/{cf_zone_id}/dns_records",
                            headers=headers,
                            json={"type": "CNAME", "name": fqdn, "content": cname_target, "proxied": True},
                        )
                        if create_resp.status_code != 200:
                            logger.error(f"Failed to create DNS record {fqdn}: {create_resp.text}")
                            return False
                        logger.info(f"Created Cloudflare DNS: {fqdn} -> {cname_target}")

                return True
        except Exception as e:
            logger.error(f"Cloudflare DNS setup failed: {e}")
            return False
    
    async def _configure_ci_variables(self, app_name: str):
        """Configure CI/CD variables using the current git provider"""
        # Build INFRA_REPO_AUTH based on provider type
        if self.provider.name == "github":
            # GitHub: x-access-token:{token}
            infra_auth = f"x-access-token:{self._credentials.get('github_token', self._credentials.get('git_token', ''))}"
        else:
            # Bitbucket: user:token
            infra_auth = f"{self.git_user}:{self.git_token}"

        variables = [
            {"key": "DOCKERHUB_USERNAME", "value": self._credentials.get("dockerhub_username", ""), "secured": False},
            {"key": "DOCKERHUB_PASSWORD", "value": self._credentials.get("dockerhub_token", ""), "secured": True},
            {"key": "INFRA_REPO_AUTH", "value": infra_auth, "secured": True},
        ]
        
        await self.provider.set_ci_variables(app_name, variables)

    # Legacy alias for backward compatibility
    async def _configure_pipeline_vars(self, app_name: str):
        """Deprecated: use _configure_ci_variables"""
        await self._configure_ci_variables(app_name)

    async def _trigger_initial_ci(self, app_name: str, environments: list):
        """Trigger the first CI run for the main branch only.
        
        develop/staging branches are already triggered automatically by
        the branch push in _create_environment_branches (step 10).
        main needs an explicit trigger because it was pushed before
        CI was enabled.
        """
        # Only trigger main — other branches auto-trigger on push
        if "prod" not in environments:
            logger.info("No prod environment — skipping main CI trigger")
            return

        try:
            result = await self.provider.trigger_ci(app_name, "main")
            if result:
                logger.info(f"Triggered CI for {app_name}/main (prod) via {self.provider.display_name}")
            else:
                logger.warning(f"CI trigger for {app_name}/main returned None")
        except Exception as e:
            logger.warning(f"Could not trigger CI for {app_name}/main: {e}")

    # Legacy alias for backward compatibility
    async def _trigger_initial_pipelines(self, app_name: str, environments: list):
        """Deprecated: use _trigger_initial_ci"""
        await self._trigger_initial_ci(app_name, environments)
    
    def _cleanup(self, paths: list):
        """Limpiar directorios temporales"""
        for path in paths:
            if path and os.path.exists(path):
                try:
                    shutil.rmtree(path)
                except:
                    pass

    async def _create_environment_branches(self, app_path: str, repo_url: str, environments: list):
        """Crear branches para cada environment seleccionado"""
        # Map environment to branch name
        env_branches = {
            "dev": "develop",
            "staging": "staging", 
            "prod": "main"  # main ya existe
        }
        
        # Auth URL already set on remote from _push_new_repo, no need to re-auth
        
        for env in environments:
            branch = env_branches.get(env)
            if branch and branch != "main":  # main ya existe
                try:
                    # Crear branch desde main
                    subprocess.run(
                        ["git", "checkout", "-b", branch],
                        cwd=app_path, check=True, capture_output=True
                    )
                    result = subprocess.run(
                        ["git", "push", "-u", "origin", branch],
                        cwd=app_path, capture_output=True, text=True
                    )
                    if result.returncode != 0:
                        logger.error(f"Failed to push branch {branch}: {self._sanitize_error(result.stderr)}")
                    # Volver a main
                    subprocess.run(
                        ["git", "checkout", "main"],
                        cwd=app_path, capture_output=True
                    )
                except subprocess.CalledProcessError as e:
                    stderr = getattr(e, 'stderr', b'')
                    if isinstance(stderr, bytes):
                        stderr = stderr.decode('utf-8', errors='replace')
                    logger.error(f"Failed to create branch {branch} for {env}: {self._sanitize_error(str(stderr))}")

    async def _generate_dynamic_pipeline(self, app_path: str, app_data, environments: list, template_details: dict = None):
        """
        Generate CI/CD config file dynamically based on the current git provider.
        Uses provider.generate_ci_yaml() to produce the correct format.
        """
        app_name = app_data.name
        dockerhub_user = self._credentials.get("dockerhub_username", "")
        workspace_or_org = self.provider._namespace()
        pipeline_email = f"pipeline@{self.domain}" if self.domain else f"pipeline@{PIPELINE_EMAIL_DOMAIN_FALLBACK}"
        template_config = getattr(app_data, 'template_config', {}) or {}
        
        # Detectar tipo de proyecto
        has_package_json = os.path.exists(os.path.join(app_path, "package.json"))
        has_requirements = os.path.exists(os.path.join(app_path, "requirements.txt"))
        
        if has_package_json:
            node_ver = template_config.get("node_version", "20")
            image = f"node:{node_ver}-alpine"
            build_steps = """      - step:
          name: "📦 Install & Build"
          caches:
            - node
          script:
            - npm ci
            - npm run build
          artifacts:
            - dist/**"""
        elif has_requirements:
            py_ver = template_config.get("python_version", "3.11")
            image = f"python:{py_ver}-slim"
            build_steps = """      - step:
          name: "📦 Install Dependencies"
          caches:
            - pip
          script:
            - pip install -r requirements.txt
          artifacts:
            - ./**"""
        else:
            image = "alpine:latest"
            build_steps = """      - step:
          name: "📦 Prepare"
          script:
            - echo "No build step required"
          artifacts:
            - ./**"""
        
        # Use provider to generate the CI YAML
        ci_filepath, ci_content = self.provider.generate_ci_yaml(
            app_name=app_name,
            environments=environments,
            image=image,
            build_steps=build_steps,
            dockerhub_user=dockerhub_user,
            workspace_or_org=workspace_or_org,
            pipeline_email=pipeline_email,
            infra_repo="infra-gitops",
        )
        
        # Ensure parent directories exist (GitHub needs .github/workflows/)
        full_path = os.path.join(app_path, ci_filepath)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(ci_content)

    async def _enable_pipelines(self, app_name: str):
        """Enable CI/CD for the repo using the current provider"""
        await self.provider.enable_ci(app_name)

    async def delete_app(self, app_name: str, environments: list[str] | None = None, provider_name: str = None):
        """
        Elimina una app completa:
        1. Git Repo (via provider)
        2. Directorio en infra-gitops
        3. Secretos en Vault
        4. Tailscale devices
        """
        await self._load_credentials(provider_override=provider_name)
        target_envs = sorted(set((environments or []) + ["dev", "staging", "prod"]))

        cleanup_report = {
            "app_name": app_name,
            "git_repo": {"deleted": False, "status": "unknown", "provider": self.provider.display_name},
            "infra": {"removed": False, "status": "unknown"},
            "vault": {"enabled": False, "deleted_paths": [], "missing_paths": [], "failed_paths": []},
            "tailscale": {"enabled": False, "deleted": [], "not_found": True, "failed": []}
        }

        # 1. Delete Git Repo via provider
        try:
            deleted = await self.provider.delete_repo(app_name)
            cleanup_report["git_repo"] = {
                "deleted": deleted,
                "status": "deleted" if deleted else "not_found",
                "provider": self.provider.display_name,
            }
        except Exception as e:
            cleanup_report["git_repo"] = {"deleted": False, "status": f"error:{e}", "provider": self.provider.display_name}
            logger.warning(f"Failed to delete {self.provider.display_name} repo {app_name}: {e}")

        # 2. Delete from infra-gitops
        infra_path = os.path.join(self.workspace, "infra-gitops")

        # Clone infra-gitops using provider auth
        auth_infra_url = self.provider.get_auth_clone_url("infra-gitops")

        if os.path.exists(infra_path):
            shutil.rmtree(infra_path)

        subprocess.run(["git", "clone", auth_infra_url, infra_path], check=True, capture_output=True)

        # Configurar git user
        subprocess.run(["git", "config", "user.email", f"kaanbal@{self.domain}"], cwd=infra_path)
        subprocess.run(["git", "config", "user.name", "Kaanbal Engine"], cwd=infra_path)

        app_dir = os.path.join(infra_path, "apps", app_name)
        
        if os.path.exists(app_dir):
            # Eliminar directorio
            subprocess.run(["git", "rm", "-r", f"apps/{app_name}"], cwd=infra_path, check=True)
            
            # Commit y Push
            subprocess.run(["git", "commit", "-m", f"chore: delete app {app_name}"], cwd=infra_path, check=True)
            subprocess.run(["git", "push", "origin", "main"], cwd=infra_path, check=True)
            cleanup_report["infra"] = {"removed": True, "status": "deleted"}
        else:
            cleanup_report["infra"] = {"removed": False, "status": "not_found"}

        # 3. Delete app secrets from Vault (hard delete metadata path)
        cleanup_report["vault"] = await self._delete_vault_app_secrets(app_name, target_envs)

        # 4. Delete Tailscale devices (Ingress and TCP Service devices)
        cleanup_report["tailscale"] = await self._delete_tailscale_devices(app_name, target_envs)
        
        # Cleanup local
        if os.path.exists(infra_path):
            shutil.rmtree(infra_path)
        
        return cleanup_report

    async def _delete_vault_app_secrets(self, app_name: str, environments: list[str]) -> dict:
        vault_addr = self._credentials.get("vault_addr", "")
        vault_token = self._credentials.get("vault_token", "")

        result = {
            "enabled": bool(vault_addr and vault_token),
            "deleted_paths": [],
            "missing_paths": [],
            "failed_paths": []
        }

        if not result["enabled"]:
            return result

        async with httpx.AsyncClient(timeout=10.0, verify=False) as client:
            for env in sorted(set(environments)):
                metadata_url = f"{vault_addr}/v1/secret/metadata/{env}/{app_name}"
                try:
                    response = await client.delete(
                        metadata_url,
                        headers={"X-Vault-Token": vault_token}
                    )
                    path = f"secret/{env}/{app_name}"
                    if response.status_code == 204:
                        result["deleted_paths"].append(path)
                    elif response.status_code == 404:
                        result["missing_paths"].append(path)
                    else:
                        result["failed_paths"].append({
                            "path": path,
                            "status": response.status_code,
                            "error": response.text[:180]
                        })
                except Exception as e:
                    result["failed_paths"].append({
                        "path": f"secret/{env}/{app_name}",
                        "status": "exception",
                        "error": str(e)
                    })

        return result

    # ---- Tailscale API Methods ----

    async def _get_tailscale_api_token(self) -> str | None:
        """
        Exchange Tailscale OAuth client credentials for a short-lived API token.
        Returns the access_token string, or None if credentials are missing/invalid.
        """
        client_id = self._credentials.get("tailscale_client_id", "")
        client_secret = self._credentials.get("tailscale_client_secret", "")
        if not client_id or not client_secret:
            return None

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(
                    TAILSCALE_OAUTH_URL,
                    data={
                        "client_id": client_id,
                        "client_secret": client_secret,
                        "grant_type": "client_credentials",
                    },
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
                if resp.status_code == 200:
                    return resp.json().get("access_token")
                logger.warning(f"Tailscale OAuth failed: {resp.status_code} {resp.text[:200]}")
                return None
        except Exception as e:
            logger.warning(f"Tailscale OAuth exception: {e}")
            return None

    async def _list_tailscale_devices(self, api_token: str) -> list[dict]:
        """List all devices in the tailnet."""
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.get(
                    f"{TAILSCALE_API_BASE}/tailnet/-/devices",
                    headers={"Authorization": f"Bearer {api_token}"},
                )
                if resp.status_code == 200:
                    return resp.json().get("devices", [])
                logger.warning(f"Tailscale list devices failed: {resp.status_code}")
                return []
        except Exception as e:
            logger.warning(f"Tailscale list devices exception: {e}")
            return []

    async def _delete_tailscale_device(self, api_token: str, device_id: str) -> bool:
        """Delete a single Tailscale device by ID. Returns True on success."""
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.delete(
                    f"{TAILSCALE_API_BASE}/device/{device_id}",
                    headers={"Authorization": f"Bearer {api_token}"},
                )
                return resp.status_code == 200
        except Exception as e:
            logger.warning(f"Tailscale delete device {device_id} exception: {e}")
            return False

    async def _delete_tailscale_devices(self, app_name: str, environments: list[str]) -> dict:
        """
        Delete all Tailscale devices associated with an app across all environments.
        
        Hostname patterns to match:
        - Ingress-based (web apps): {env}-{app_name}-ts-ingress
        - TCP Service-based (databases): {env}-{app_name}
        """
        result = {
            "enabled": False,
            "deleted": [],
            "not_found": True,
            "failed": [],
        }

        api_token = await self._get_tailscale_api_token()
        if not api_token:
            logger.info("Tailscale API credentials not configured, skipping device cleanup")
            return result

        result["enabled"] = True

        # Build set of hostname patterns to match for this app
        target_hostnames = set()
        for env in environments:
            # Ingress pattern (web apps): {env}-{app_name}-ts-ingress
            target_hostnames.add(f"{env}-{app_name}-ts-ingress")
            # TCP Service pattern (databases): {env}-{app_name}
            target_hostnames.add(f"{env}-{app_name}")

        # Also check stored tailscale_hostname from MongoDB
        db = get_db()
        app_doc = await db.apps.find_one(
            {"name": app_name},
            {"connection_info.per_env_exposure": 1}
        )
        if app_doc:
            per_env = app_doc.get("connection_info", {}).get("per_env_exposure", {})
            for env_data in per_env.values():
                ts_hostname = env_data.get("tailscale_hostname", "")
                if ts_hostname:
                    target_hostnames.add(ts_hostname)

        devices = await self._list_tailscale_devices(api_token)

        for device in devices:
            hostname = device.get("hostname", "")
            device_id = device.get("id", "")
            if hostname in target_hostnames:
                result["not_found"] = False
                success = await self._delete_tailscale_device(api_token, device_id)
                if success:
                    result["deleted"].append({"hostname": hostname, "id": device_id})
                    logger.info(f"Deleted Tailscale device: {hostname} ({device_id})")
                else:
                    result["failed"].append({"hostname": hostname, "id": device_id})
                    logger.warning(f"Failed to delete Tailscale device: {hostname} ({device_id})")

        return result

    async def cleanup_orphan_tailscale_devices(self, active_app_names: set[str], environments: list[str], dry_run: bool = False) -> dict:
        """
        Find and optionally delete Tailscale devices that don't belong to any active app.
        Ignores system devices (tailscale-operator, vault-*, personal machines, infra services).
        Also checks stored connection_info.per_env_exposure tailscale_hostname values from MongoDB.
        """
        await self._load_credentials()
        result = {
            "enabled": False,
            "dry_run": dry_run,
            "active_apps": sorted(active_app_names),
            "orphans": [],
            "deleted": [],
            "failed": [],
            "system_devices": [],
        }

        api_token = await self._get_tailscale_api_token()
        if not api_token:
            return result

        result["enabled"] = True
        devices = await self._list_tailscale_devices(api_token)

        # System hostnames to never touch
        system_prefixes = ("tailscale-operator", "vault-", "andresbc")

        # Build known hostnames set: standard patterns + stored tailscale_hostname from DB
        known_hostnames = set()
        for env in environments:
            for app_name in active_app_names:
                known_hostnames.add(f"{env}-{app_name}-ts-ingress")
                known_hostnames.add(f"{env}-{app_name}")

        # Also collect tailscale_hostname values from all active apps in MongoDB
        db = get_db()
        app_docs = await db.apps.find(
            {"name": {"$in": list(active_app_names)}},
            {"name": 1, "connection_info.per_env_exposure": 1}
        ).to_list(300)
        for doc in app_docs:
            per_env = doc.get("connection_info", {}).get("per_env_exposure", {})
            for env_data in per_env.values():
                ts_hostname = env_data.get("tailscale_hostname", "")
                if ts_hostname:
                    known_hostnames.add(ts_hostname)

        # Also load infra_tailscale_hostnames from system_config (manually managed services)
        ts_dns_suffix = self._credentials.get("tailscale_dns_suffix", TAILSCALE_DNS_SUFFIX)
        config = await db.system_config.find_one({"_id": "main"})
        if config:
            for h in config.get("infra_tailscale_hostnames", []):
                # Strip FQDN suffix if present, store the bare hostname
                known_hostnames.add(h.replace(f".{ts_dns_suffix}", ""))

        for device in devices:
            hostname = device.get("hostname", "")
            device_id = device.get("id", "")

            # Skip system devices
            if any(hostname.startswith(p) for p in system_prefixes):
                result["system_devices"].append(hostname)
                continue

            # Check against all known hostnames (patterns + DB-stored)
            if hostname in known_hostnames:
                continue

            result["orphans"].append({"hostname": hostname, "id": device_id})
            if not dry_run:
                success = await self._delete_tailscale_device(api_token, device_id)
                if success:
                    result["deleted"].append(hostname)
                else:
                    result["failed"].append(hostname)

        return result

    async def cleanup_orphan_vault_secrets(self, active_app_names: set[str], environments: list[str], dry_run: bool = False) -> dict:
        await self._load_credentials()
        vault_addr = self._credentials.get("vault_addr", "")
        vault_token = self._credentials.get("vault_token", "")

        report = {
            "enabled": bool(vault_addr and vault_token),
            "dry_run": dry_run,
            "active_apps": sorted(active_app_names),
            "orphans": {},
            "deleted": [],
            "failed": []
        }

        if not report["enabled"]:
            return report

        envs = sorted(set(environments or ["dev", "staging", "prod"]))

        async with httpx.AsyncClient(timeout=10.0, verify=False) as client:
            for env in envs:
                try:
                    list_response = await client.get(
                        f"{vault_addr}/v1/secret/metadata/{env}",
                        headers={"X-Vault-Token": vault_token},
                        params={"list": "true"}
                    )

                    if list_response.status_code == 404:
                        report["orphans"][env] = []
                        continue

                    if list_response.status_code != 200:
                        report["failed"].append({
                            "path": f"secret/{env}",
                            "status": list_response.status_code,
                            "error": list_response.text[:180]
                        })
                        report["orphans"][env] = []
                        continue

                    keys = list_response.json().get("data", {}).get("keys", [])
                    normalized = [k.rstrip("/") for k in keys if k]
                    orphans = sorted([k for k in normalized if k not in active_app_names])
                    report["orphans"][env] = orphans

                    if dry_run:
                        continue

                    for orphan in orphans:
                        delete_response = await client.delete(
                            f"{vault_addr}/v1/secret/metadata/{env}/{orphan}",
                            headers={"X-Vault-Token": vault_token}
                        )
                        path = f"secret/{env}/{orphan}"
                        if delete_response.status_code in [204, 404]:
                            report["deleted"].append(path)
                        else:
                            report["failed"].append({
                                "path": path,
                                "status": delete_response.status_code,
                                "error": delete_response.text[:180]
                            })
                except Exception as e:
                    report["failed"].append({
                        "path": f"secret/{env}",
                        "status": "exception",
                        "error": str(e)
                    })

        return report