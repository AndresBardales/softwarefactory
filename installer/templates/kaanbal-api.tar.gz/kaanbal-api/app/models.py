from pydantic import BaseModel, Field
from typing import Optional, Dict, List, Any
from datetime import datetime
from enum import Enum


class ExposureType(str, Enum):
    PUBLIC = "public"
    TAILSCALE = "tailscale"
    BOTH = "both"
    INTERNAL = "internal"


class User(BaseModel):
    username: str
    email: Optional[str] = None
    disabled: Optional[bool] = None
    role: str = "user"  # "admin" or "user"


class UserInDB(User):
    hashed_password: str


class Token(BaseModel):
    access_token: str
    token_type: str


class TokenData(BaseModel):
    username: Optional[str] = None


class PortDefinition(BaseModel):
    """Definition of a single port exposed by an application"""
    name: str = Field(..., description="Port identifier, e.g. 'mqtt', 'dashboard', 'http'")
    port: int = Field(..., description="Port number, e.g. 1883, 18083, 80")
    protocol: str = Field(default="TCP", description="TCP or UDP")
    description: str = Field(default="", description="Human-readable description")


class ResourceSpec(BaseModel):
    cpu_request: str = "100m"
    cpu_limit: str = "500m"
    mem_request: str = "128Mi"
    mem_limit: str = "512Mi"


class AppSpecs(BaseModel):
    replicas: int = 1
    port: int = 80
    resources: ResourceSpec = ResourceSpec()


class ExposureConfig(BaseModel):
    type: ExposureType = ExposureType.INTERNAL
    public_path: str = "/"
    tailscale_hostname: Optional[str] = None
    per_env: Optional[Dict[str, ExposureType]] = None
    # Multi-port support: per-port-per-env exposure
    ports: Optional[List[PortDefinition]] = Field(default=None, description="Port definitions for multi-port apps")
    port_exposure: Optional[Dict[str, Dict[str, str]]] = Field(
        default=None,
        description="Per-env per-port exposure map: { 'prod': { 'mqtt': 'public', 'dashboard': 'tailscale' } }"
    )


class Environment(str, Enum):
    """Ambientes de despliegue disponibles"""
    DEV = "dev"
    STAGING = "staging"
    PROD = "prod"


class CreationMode(str, Enum):
    """Modos de creación de apps"""
    SCAFFOLD = "scaffold"      # Crear desde CLI oficial (vue create, etc)
    EMPTY = "empty"            # Repo vacío, usuario sube código
    UPLOAD = "upload"          # Usuario sube ZIP o importa repo
    CONFIG_ONLY = "config-only"  # Solo K8s manifests, sin código


class AppStatus(str, Enum):
    """Estados de una app durante su ciclo de vida"""
    CREATED = "created"                # Registro creado, sin repo
    REPO_READY = "repo_ready"          # Repo existe, esperando código
    AWAITING_CODE = "awaiting_code"    # Repo vacío, usuario debe pushear
    PIPELINE_RUNNING = "pipeline_running"  # Pipeline ejecutándose
    PIPELINE_FAILED = "pipeline_failed"   # Pipeline falló
    IMAGE_READY = "image_ready"        # Docker image lista
    DEPLOYING = "deploying"            # ArgoCD sync en progreso
    HEALTHY = "healthy"                # Todo funcionando
    DEGRADED = "degraded"              # Algunos ambientes con problemas
    OFFLINE = "offline"                # App detenida intencionalmente


class AppCreate(BaseModel):
    """Request body para crear una nueva app"""
    name: str = Field(..., description="Nombre de la app (slug)")
    template: str = Field(..., description="Template a usar: vue3-spa, fastapi-api, etc.")
    category: Optional[str] = Field(default=None, description="Template category: frontend, backend, database, workflow, etc.")
    description: str = ""
    client_id: Optional[str] = None
    environments: List[str] = Field(default=["dev"], description="Environments to deploy: dev, staging, prod")
    creation_mode: CreationMode = Field(default=CreationMode.SCAFFOLD, description="How to create the app")
    scaffold_option: Optional[str] = Field(default=None, description="Which scaffold to use (vue3, react, etc)")
    git_provider: Optional[str] = Field(default=None, description="Git provider override: bitbucket, github (uses system default if None)")
    template_config: Optional[Dict[str, Any]] = Field(default=None, description="Dynamic config based on template schema")
    exposure: ExposureConfig = ExposureConfig()
    specs: AppSpecs = AppSpecs()


class App(BaseModel):
    """App en la base de datos"""
    id: str = Field(alias="_id")
    name: str
    template: str
    description: str = ""
    client_id: Optional[str] = None
    environments: List[str] = ["prod"]  # Array of environments: dev, staging, prod
    creation_mode: str = "scaffold"  # scaffold, empty, upload, config-only
    exposure: ExposureConfig
    specs: AppSpecs
    status: str = "created"  # created, repo_ready, awaiting_code, pipeline_running, pipeline_failed, healthy, degraded, offline
    repo_url: Optional[str] = None
    subdomain: Optional[str] = None
    # Pipeline tracking
    last_pipeline_status: Optional[str] = None  # SUCCESSFUL, FAILED, IN_PROGRESS
    last_pipeline_build: Optional[int] = None   # Build number
    last_pipeline_at: Optional[datetime] = None
    # Timestamps
    created_at: datetime
    updated_at: datetime
    
    class Config:
        populate_by_name = True


class ClientCreate(BaseModel):
    """Request body para crear un cliente"""
    name: str
    slug: str = Field(..., description="Identificador único (ej: acme-corp)")
    contact_email: str
    plan: str = "starter"  # starter, pro, enterprise


class Client(BaseModel):
    """Cliente en la base de datos"""
    id: str = Field(alias="_id")
    name: str
    slug: str
    contact_email: str
    plan: str
    apps: List[str] = []  # Lista de app IDs
    created_at: datetime
    
    class Config:
        populate_by_name = True


class SystemConfig(BaseModel):
    """Configuración del sistema"""
    git_provider: Optional[str] = "bitbucket"
    git_username: str
    git_token_masked: str  # Solo mostrar últimos 4 chars
    bitbucket_email: str
    bitbucket_workspace: str
    infra_repo_url: str
    domain: str
    dockerhub_username: str
    dockerhub_token_masked: str
    # GitHub
    github_org: Optional[str] = ""
    github_token_masked: Optional[str] = "****"
    github_is_org: Optional[bool] = False
    # AI Config
    ai_provider: Optional[str] = "deepseek"
    ai_model: Optional[str] = "deepseek-chat"
    ai_base_url: Optional[str] = "https://api.deepseek.com"
    ai_api_key_masked: Optional[str] = "****"
    # ArgoCD Config
    argocd_server: Optional[str] = "http://argocd-server.argocd.svc.cluster.local:80"
    argocd_username: Optional[str] = "admin"
    argocd_password_masked: Optional[str] = "****"


class SystemConfigUpdate(BaseModel):
    """Para actualizar configuración"""
    # Platform
    mode: Optional[str] = None
    domain: Optional[str] = None
    # Git
    git_provider: Optional[str] = None
    git_username: Optional[str] = None
    git_token: Optional[str] = None
    bitbucket_email: Optional[str] = None
    bitbucket_workspace: Optional[str] = None
    # GitHub
    github_org: Optional[str] = None
    github_token: Optional[str] = None
    github_is_org: Optional[bool] = None
    # Docker
    dockerhub_username: Optional[str] = None
    dockerhub_token: Optional[str] = None
    # Cloudflare
    cloudflare_token: Optional[str] = None
    cloudflare_account_id: Optional[str] = None
    # Tailscale
    tailscale_client_id: Optional[str] = None
    tailscale_client_secret: Optional[str] = None
    tailscale_dns_suffix: Optional[str] = None
    # AI Config
    ai_provider: Optional[str] = None
    ai_api_key: Optional[str] = None
    ai_model: Optional[str] = None
    ai_base_url: Optional[str] = None
    # ArgoCD Config
    argocd_server: Optional[str] = None
    argocd_username: Optional[str] = None
    argocd_password: Optional[str] = None


# ============ API TOKENS ============

class APITokenCreate(BaseModel):
    """Request para crear un API Token"""
    name: str = Field(..., description="Nombre descriptivo (ej: Jira Integration)")
    scopes: List[str] = Field(default=["read"], description="Permisos: read, write, apps:create, apps:delete, templates:manage")


class APIToken(BaseModel):
    """API Token en respuesta (sin key completa)"""
    id: str = Field(alias="_id")
    name: str
    scopes: List[str]
    key_prefix: str  # Solo primeros 8 chars
    is_active: bool = True
    created_at: datetime
    last_used_at: Optional[datetime] = None
    
    class Config:
        populate_by_name = True


class APITokenCreated(BaseModel):
    """Respuesta al crear token (única vez que se muestra key completa)"""
    id: str
    name: str
    key: str  # ⚠️ Solo se muestra UNA VEZ
    scopes: List[str]
    message: str = "Guarda este token, no podrás verlo de nuevo"


class WebhookDeployRequest(BaseModel):
    """Payload para webhook de deploy (compatible con tu n8n actual)"""
    metadata: Dict = {}
    project: Dict
    app: Dict
    specs: Dict = {}
    exposure: Optional[Dict] = None
    gitConfig: Dict = {}
    infra: Dict = {}


# ============ CUSTOM TEMPLATES ============

class TemplateStatus(str, Enum):
    """Estados de validación de un template personalizado"""
    DRAFT = "draft"              # Recién creado, sin validar
    VALIDATING = "validating"    # Pruebas en progreso
    VALIDATION_FAILED = "validation_failed"  # Alguna prueba falló
    READY = "ready"              # Validado y listo para usar


class TemplateTestApp(BaseModel):
    """App temporal de prueba para validar un template"""
    environment: str              # dev, staging, prod
    app_name: str                 # Nombre de la app de prueba
    status: str = "pending"       # pending, deploying, healthy, failed
    error_message: Optional[str] = None
    created_at: Optional[datetime] = None


class CustomTemplateCreate(BaseModel):
    """Request para crear un template personalizado"""
    id: str = Field(..., description="Slug único, ej: vue3-dashboard")
    name: str = Field(..., description="Nombre display")
    description: str = ""
    category: str = Field(..., description="frontend, backend, database, service")
    icon: str = "cube"
    stack: List[str] = []
    base_template: Optional[str] = None  # Si es variante de otro
    environments: List[str] = Field(default=["dev", "prod"], description="Ambientes que soporta")
    creation_modes: List[str] = Field(default=["scaffold", "empty"], description="Modos de creación permitidos")
    # Pipeline config
    dockerfile_template: Optional[str] = None
    pipeline_template: Optional[str] = None
    # K8s config
    default_port: int = 80
    default_replicas: int = 1
    health_check_path: str = "/"


class CustomTemplate(BaseModel):
    """Template personalizado en la base de datos"""
    id: str = Field(alias="_id")
    name: str
    description: str = ""
    category: str
    icon: str = "cube"
    stack: List[str] = []
    base_template: Optional[str] = None
    environments: List[str] = ["dev", "prod"]
    creation_modes: List[str] = ["scaffold", "empty"]
    # Status de validación
    status: TemplateStatus = TemplateStatus.DRAFT
    test_apps: List[TemplateTestApp] = []
    validation_started_at: Optional[datetime] = None
    validation_completed_at: Optional[datetime] = None
    # Pipeline config
    dockerfile_template: Optional[str] = None
    pipeline_template: Optional[str] = None
    # K8s config
    default_port: int = 80
    default_replicas: int = 1
    health_check_path: str = "/"
    # Metadata
    created_by: str = "system"
    created_at: datetime = None
    updated_at: datetime = None
    
    class Config:
        populate_by_name = True
