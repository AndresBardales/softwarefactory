# Kaanbal Templates

Official template catalog for **Kaanbal Engine**.

## Available Templates

| Template | Category | Stack | Description |
|----------|----------|-------|-------------|
| **vue3-spa** | Frontend | Vue 3, Vite, Tailwind | Modern SPA |
| **fastapi-api** | Backend | Python, FastAPI | High-performance async API |
| **mongodb-db** | Database | MongoDB 7 | NoSQL with persistence |
| **mysql-db** | Database | MySQL 8 | Relational DB with persistence |
| **postgres-db** | Database | PostgreSQL 16 | Advanced relational DB |
| **n8n-workflow** | Workflow | n8n | Workflow automation |
| **emqx-broker** | IoT | EMQX | MQTT broker |

## Structure

```
kaanbal-templates/
├── catalog.json            # Master catalog definition
├── manifest.json           # Template index for API
├── template-schema.json    # JSON Schema for validation
├── vue3-spa/               # Frontend template
├── fastapi-api/            # Backend template
├── mongodb-db/             # Database template
├── mysql-db/               # Database template
├── postgres-db/            # Database template
├── n8n-workflow/           # Workflow template
├── emqx-broker/            # IoT template
├── stacks/                 # Pre-configured combinations
└── templates/              # V4 structured templates
```

## Placeholders

Each template uses standard placeholders replaced during deployment:

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `placeholder-app` | Application name | `my-api` |
| `example.com` | Domain | `your-domain.com` |
| `__DOCKER_USER__` | Docker Hub username | `mycompany` |

## CI/CD

Templates generate GitHub Actions workflows for deployed apps:

| Secret | Description |
|--------|-------------|
| `DOCKERHUB_USERNAME` | Docker Hub username |
| `DOCKERHUB_TOKEN` | Docker Hub access token |
| `INFRA_GIT_TOKEN` | Token for infra-gitops updates |

## Environments

Templates support multiple deployment environments:

- **dev**: Development (branch: `develop`, tag: `dev-<commit>`)
- **staging**: Pre-production (branch: `staging`, tag: `staging-<commit>`)
- **prod**: Production (branch: `main`, tag: `<commit>`)

## Creating a New Template

1. Create a folder with your template ID
2. Add `template.json` with metadata
3. Include CI workflow (GitHub Actions)
4. Add `Dockerfile` for containerization
5. Create `k8s/` with Kustomize base + overlays
6. Update `manifest.json` to register the template

---

*Part of [Kaanbal Engine](https://github.com/AndresBardales/softwarefactory)*
