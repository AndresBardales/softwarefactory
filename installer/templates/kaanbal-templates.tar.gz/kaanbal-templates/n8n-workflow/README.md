# placeholder-app

## Descripción
Este repositorio contiene una configuración personalizada de n8n diseñada para desplegar flujos de trabajo automatizados con herramientas adicionales preinstaladas. La imagen Docker incluye soporte para Python, FFmpeg, Git y jq, permitiendo una mayor flexibilidad en los nodos de ejecución de comandos.

## Cómo construir la imagen

Para construir la imagen Docker localmente, ejecuta el siguiente comando en la raíz del proyecto:

```bash
docker build -t placeholder-app:latest .
```

Para ejecutar el contenedor:

```bash
docker run -it --rm -p 5678:5678 placeholder-app:latest
```

## Scripts incluidos

Los scripts personalizados se encuentran en el directorio `/data/scripts` dentro del contenedor.

- `hello.py`: Script de prueba para verificar la ejecución de Python. Imprime un mensaje de saludo.

## Variables de Entorno Requeridas

Para el correcto funcionamiento de n8n y las integraciones, asegúrate de configurar las siguientes variables de entorno (puedes usar un archivo `.env` o configurarlas en tu orquestador):

- `N8N_BASIC_AUTH_ACTIVE`: (true/false) Activar autenticación básica.
- `N8N_BASIC_AUTH_USER`: Usuario para autenticación básica.
- `N8N_BASIC_AUTH_PASSWORD`: Contraseña para autenticación básica.
- `N8N_HOST`: Host donde se ejecuta n8n.
- `N8N_PORT`: Puerto de n8n (por defecto 5678).
- `N8N_PROTOCOL`: (http/https).
- `WEBHOOK_URL`: URL pública para los webhooks.
