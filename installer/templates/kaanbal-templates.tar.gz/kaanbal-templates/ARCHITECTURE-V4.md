# 🏭 Kaanbal Engine - Arquitectura v4.0

> **Visión**: Una fábrica de software donde cualquier tecnología puede desplegarse en minutos.  
> **Modelo**: App Store / Play Store para infraestructura cloud-native.

---

## 📊 Análisis del Estado Actual

### Lo que tenemos funcionando:
- ✅ Sistema de templates básico (vue3-spa, fastapi-api, n8n, mongodb)
- ✅ Pipeline CI/CD con GitHub Actions
- ✅ ArgoCD para GitOps
- ✅ Multi-environment (dev/staging/prod)
- ✅ Exposición pública + Tailscale VPN
- ✅ Sistema de validación de templates
- ✅ Creación de apps con diferentes modos (scaffold/empty/config-only)

### Gaps identificados:
- ❌ No hay stacks (combinaciones de tecnologías)
- ❌ No hay importación directa de Docker Hub
- ❌ Configuraciones hardcodeadas en templates
- ❌ No hay relación entre servicios dependientes
- ❌ Exposición mixta (público + VPN) no está estandarizada

---

## 🎯 Nueva Arquitectura Propuesta

### 1. JERARQUÍA DE CONCEPTOS

```
┌─────────────────────────────────────────────────────────────────┐
│                         KAANBAL CATALOG                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────┐        │
│  │  CATEGORIES  │   │  TEMPLATES   │   │   STACKS     │        │
│  │  (frontend,  │──▶│  (vue, fast  │──▶│  (fullstack  │        │
│  │   backend,   │   │   api, n8n)  │   │   combos)    │        │
│  │   database)  │   └──────────────┘   └──────────────┘        │
│  └──────────────┘           │                  │                │
│                             │                  │                │
│                             ▼                  ▼                │
│                    ┌──────────────────────────────────┐        │
│                    │           APPLICATIONS           │        │
│                    │    (instancias desplegadas)      │        │
│                    └──────────────────────────────────┘        │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### 2. CATEGORÍAS MAESTRAS

| Categoría | Descripción | Modo Creación | Necesita Repo | Ejemplos |
|-----------|-------------|---------------|---------------|----------|
| **frontend** | Interfaces web | scaffold/empty/upload | ✅ Sí | Vue, React, Angular |
| **backend** | APIs y servicios | scaffold/empty/upload | ✅ Sí | FastAPI, Express, Laravel |
| **database** | Almacenamiento | config-only | ❌ No | MongoDB, MySQL, Redis |
| **workflow** | Automatización | config-only/upload | ⚠️ Opcional | n8n, Node-RED, Airflow |
| **iot** | IoT/Edge | config-only/upload | ⚠️ Opcional | EMQX, Mosquitto |
| **monitoring** | Observabilidad | config-only | ❌ No | Grafana, Prometheus |
| **devtools** | Herramientas dev | config-only | ❌ No | phpMyAdmin, Adminer |

### 3. CATÁLOGO DE TEMPLATES

#### 📱 FRONTEND
| ID | Nombre | Stack | Puerto | Scaffold | Notas |
|----|--------|-------|--------|----------|-------|
| `vue3-spa` | Vue 3 SPA | Vue3, Vite, Tailwind | 80 | `npm create vue@latest` | ⭐ Popular |
| `react-spa` | React SPA | React, Vite, Tailwind | 80 | `npm create vite -- --template react-ts` | |
| `angular-app` | Angular App | Angular, Material | 80 | `ng new` | |
| `next-app` | Next.js | Next.js, React | 3000 | `npx create-next-app` | SSR |
| `nuxt-app` | Nuxt 3 | Nuxt, Vue3 | 3000 | `npx nuxi init` | SSR |

#### ⚙️ BACKEND
| ID | Nombre | Stack | Puerto | Scaffold | Notas |
|----|--------|-------|--------|----------|-------|
| `fastapi-api` | FastAPI | Python, Pydantic | 8000 | cookiecutter | ⭐ Popular |
| `express-api` | Express.js | Node.js, Express | 3000 | `npx express-generator` | |
| `nestjs-api` | NestJS | Node.js, TypeScript | 3000 | `npx @nestjs/cli new` | Enterprise |
| `laravel-api` | Laravel | PHP, Laravel | 8000 | `composer create-project` | |
| `django-api` | Django | Python, Django | 8000 | `django-admin startproject` | |
| `flask-api` | Flask | Python, Flask | 5000 | cookiecutter | Lightweight |

#### 💾 DATABASE
| ID | Nombre | Imagen Docker | Puerto | Persistencia | Notas |
|----|--------|---------------|--------|--------------|-------|
| `mongodb` | MongoDB | mongo:7 | 27017 | ✅ PVC | ⭐ Default |
| `mysql` | MySQL | mysql:8 | 3306 | ✅ PVC | |
| `postgres` | PostgreSQL | postgres:16 | 5432 | ✅ PVC | |
| `redis` | Redis | redis:7-alpine | 6379 | ⚠️ Opcional | Cache |
| `mariadb` | MariaDB | mariadb:11 | 3306 | ✅ PVC | |

#### 🔄 WORKFLOW
| ID | Nombre | Imagen Docker | Puerto | Exposición | Notas |
|----|--------|---------------|--------|------------|-------|
| `n8n` | n8n | n8nio/n8n:latest | 5678 | Mixta* | ⭐ Popular |
| `node-red` | Node-RED | nodered/node-red | 1880 | Tailscale | |
| `airflow` | Airflow | apache/airflow | 8080 | Tailscale | Enterprise |

#### 📡 IOT
| ID | Nombre | Imagen Docker | Puerto | Exposición | Notas |
|----|--------|---------------|--------|------------|-------|
| `emqx` | EMQX | emqx/emqx | 1883,8083 | Mixta* | MQTT Broker |
| `mosquitto` | Mosquitto | eclipse-mosquitto | 1883 | Tailscale | Lightweight |

#### 📊 MONITORING
| ID | Nombre | Imagen Docker | Puerto | Exposición | Notas |
|----|--------|---------------|--------|------------|-------|
| `grafana` | Grafana | grafana/grafana | 3000 | Tailscale | |
| `prometheus` | Prometheus | prom/prometheus | 9090 | Tailscale | |

#### 🛠️ DEVTOOLS
| ID | Nombre | Imagen Docker | Puerto | Exposición | Notas |
|----|--------|---------------|--------|------------|-------|
| `phpmyadmin` | phpMyAdmin | phpmyadmin:latest | 80 | Tailscale | MySQL UI |
| `adminer` | Adminer | adminer:latest | 8080 | Tailscale | Multi-DB UI |
| `mongo-express` | Mongo Express | mongo-express | 8081 | Tailscale | MongoDB UI |

---

## 🔗 SISTEMA DE STACKS

Los stacks permiten desplegar combinaciones predefinidas de servicios que funcionan juntos.

### Definición de Stack

```json
{
    "id": "fullstack-vue-fastapi",
    "name": "Vue + FastAPI + MongoDB",
    "description": "Stack completo para apps modernas",
    "components": [
        {
            "role": "frontend",
            "template": "vue3-spa",
            "suffix": "-web",
            "depends_on": ["backend"]
        },
        {
            "role": "backend", 
            "template": "fastapi-api",
            "suffix": "-api",
            "depends_on": ["database"],
            "env_inject": {
                "MONGODB_URI": "mongodb://{{database}}:27017/{{APP_NAME}}"
            }
        },
        {
            "role": "database",
            "template": "mongodb",
            "suffix": "-db",
            "depends_on": []
        }
    ],
    "wiring": {
        "frontend_to_backend": {
            "env_var": "VITE_API_URL",
            "value": "https://{{backend}}.{{DOMAIN}}"
        }
    }
}
```

### Stacks Propuestos

| Stack ID | Componentes | Caso de Uso |
|----------|-------------|-------------|
| `fullstack-vue-fastapi` | Vue + FastAPI + MongoDB | Apps modernas |
| `fullstack-react-express` | React + Express + MongoDB | MERN stack |
| `laravel-mysql` | Laravel + MySQL + phpMyAdmin | PHP apps |
| `django-postgres` | Django + PostgreSQL + Adminer | Python apps |
| `api-with-cache` | FastAPI + MongoDB + Redis | High performance |
| `workflow-complete` | n8n + MongoDB | Automatización |
| `iot-platform` | EMQX + Node-RED + MongoDB + Grafana | IoT |

---

## 🌐 SISTEMA DE EXPOSICIÓN

### Modos de Exposición

| Modo | Descripción | Uso típico | Ejemplo |
|------|-------------|------------|---------|
| **public** | Internet vía Traefik | Websites, APIs públicas | `app.your-domain.com` |
| **tailscale** | Solo VPN privada | Dashboards internos, DBs | `app.tail.your-domain.com` |
| **both** | Público + VPN | n8n (webhooks + UI) | Ambos subdominios |
| **internal** | Solo cluster | DB internas | Solo service K8s |

### Casos Especiales

```yaml
# n8n: UI privada, webhooks públicos
n8n:
  exposure:
    type: both
    public:
      paths: ["/webhook/*", "/webhook-test/*"]
    tailscale:
      paths: ["/*"]  # Todo lo demás
      
# Redis: Solo accesible desde el cluster
redis:
  exposure:
    type: internal
    service_name: "{{APP_NAME}}-redis.{{NAMESPACE}}.svc.cluster.local"
```

---

## 🎛️ CONFIGURACIONES POR TEMPLATE

Cada template tiene configuraciones específicas que el usuario puede modificar:

### Frontend (Vue, React, etc.)
```yaml
config:
  build:
    node_version: "20"  # o 18, 22
    package_manager: "npm"  # o yarn, pnpm
    build_command: "npm run build"
    output_dir: "dist"
  runtime:
    nginx_config: "default"  # o spa-history, static
  resources:
    cpu_request: "50m"
    memory_request: "64Mi"
```

### Backend (FastAPI, Express, etc.)
```yaml
config:
  build:
    language_version: "3.11"  # Python version
    install_command: "pip install -r requirements.txt"
    run_command: "uvicorn main:app --host 0.0.0.0"
  runtime:
    workers: 2
    timeout: 30
  resources:
    cpu_request: "100m"
    memory_request: "256Mi"
  secrets:
    - name: DATABASE_URL
      auto_generate: false
    - name: SECRET_KEY
      auto_generate: true
```

### Database (MongoDB, MySQL, etc.)
```yaml
config:
  storage:
    size: "5Gi"  # o 10Gi, 20Gi
    storage_class: "gp2"  # AWS EBS
  resources:
    cpu_request: "100m"
    memory_request: "256Mi"
  auth:
    root_password: auto_generate
    database_name: "{{APP_NAME}}"
  backup:
    enabled: false
    schedule: "0 2 * * *"
```

### Workflow (n8n, Node-RED)
```yaml
config:
  storage:
    size: "2Gi"
  timezone: "America/Mexico_City"
  exposure:
    webhooks_public: true
    ui_public: false
  resources:
    cpu_request: "100m"
    memory_request: "256Mi"
```

---

## 🔄 FLUJO DE CREACIÓN DE APP

### Opción 1: Template Simple

```
1. Usuario selecciona template (ej: vue3-spa)
2. Ingresa nombre de app
3. Selecciona environments (dev, prod)
4. Selecciona exposición (public/tailscale)
5. Ajusta configuración (opcional)
6. Deploy!
```

### Opción 2: Stack Completo

```
1. Usuario selecciona stack (ej: fullstack-vue-fastapi)
2. Ingresa nombre base (ej: "myproject")
3. Sistema propone:
   - myproject-web (Vue)
   - myproject-api (FastAPI)  
   - myproject-db (MongoDB)
4. Usuario ajusta cada componente
5. Deploy all!
```

### Opción 3: Docker Hub Import

```
1. Usuario selecciona "Import from Docker Hub"
2. Ingresa imagen (ej: grafana/grafana:latest)
3. Sistema detecta:
   - Puerto expuesto (3000)
   - Variables de entorno comunes
   - Volúmenes necesarios
4. Usuario configura exposición y storage
5. Deploy!
```

---

## 📁 NUEVA ESTRUCTURA DE TEMPLATES

```
kaanbal-templates/
├── manifest.json              # Índice de todo
├── schema.json                # JSON Schema de validación
├── categories/
│   └── {category}.json        # Definición de categoría
├── templates/
│   ├── frontend/
│   │   ├── vue3-spa/
│   │   │   ├── template.json  # Metadata
│   │   │   ├── Dockerfile     # Dockerfile base
│   │   │   ├── pipeline.yml   # Pipeline base
│   │   │   └── k8s/           # Manifests K8s
│   │   └── react-spa/
│   ├── backend/
│   │   ├── fastapi-api/
│   │   ├── express-api/
│   │   └── laravel-api/
│   ├── database/
│   │   ├── mongodb/
│   │   ├── mysql/
│   │   └── redis/
│   ├── workflow/
│   │   ├── n8n/
│   │   └── node-red/
│   └── monitoring/
│       └── grafana/
├── stacks/
│   ├── fullstack-vue-fastapi.json
│   ├── laravel-mysql.json
│   └── iot-platform.json
└── dockerhub/
    └── mappings.json          # Mapeo de imágenes conocidas
```

---

## 🚀 PLAN DE IMPLEMENTACIÓN

### Fase 1: Estructura Base (1-2 días)
- [ ] Crear nueva estructura de carpetas en kaanbal-templates
- [ ] Migrar templates existentes (vue3, fastapi, n8n, mongodb)
- [ ] Crear template.json para cada uno con todas las configs

### Fase 2: Nuevos Templates (3-4 días)
- [ ] Backend: Express, Laravel, Django, Flask
- [ ] Frontend: React, Angular, Next.js
- [ ] Database: MySQL, PostgreSQL, Redis
- [ ] Workflow: Node-RED
- [ ] Monitoring: Grafana
- [ ] DevTools: phpMyAdmin, Adminer

### Fase 3: Sistema de Stacks (2-3 días)
- [ ] Modelo de Stack en backend
- [ ] API endpoints para stacks
- [ ] UI para crear stacks
- [ ] Wiring automático entre componentes

### Fase 4: Docker Hub Import (2-3 días)
- [ ] API para buscar en Docker Hub
- [ ] Detección automática de puertos/volumes
- [ ] UI de importación
- [ ] Mappings para imágenes populares

### Fase 5: Configuración Avanzada (2-3 días)
- [ ] UI para editar configs por template
- [ ] Presets de configuración
- [ ] Validación de configuraciones
- [ ] Documentación inline

---

## 🎯 RESULTADO FINAL

Una vez implementado, el usuario podrá:

1. **Desplegar cualquier tecnología en minutos**
   - Templates predefinidos para las tecnologías más usadas
   - Configuraciones sensatas por defecto

2. **Crear stacks completos con un click**
   - Frontend + Backend + Database wired automatically
   - Variables de entorno inyectadas

3. **Importar desde Docker Hub**
   - Cualquier imagen pública
   - Detección automática de configuración

4. **Agregar nuevas tecnologías fácilmente**
   - Crear template custom con validación
   - Compartir con el equipo

5. **Exposición flexible**
   - Público, privado (VPN), o mixto
   - Configuración por paths para webhooks

---

## 📋 QUICK REFERENCE: Templates a Crear

### Prioritarios (Semana 1)
1. ✅ vue3-spa (ya existe)
2. ✅ fastapi-api (ya existe)
3. ✅ mongodb (ya existe)
4. ✅ n8n (ya existe)
5. 🔲 express-api
6. 🔲 mysql
7. 🔲 redis
8. 🔲 grafana

### Siguiente batch (Semana 2)
9. 🔲 react-spa
10. 🔲 node-red
11. 🔲 postgres
12. 🔲 laravel-api
13. 🔲 phpmyadmin

### Futuro
14. 🔲 django-api
15. 🔲 flask-api
16. 🔲 angular-app
17. 🔲 next-app
18. 🔲 emqx
19. 🔲 prometheus
20. 🔲 nestjs-api
