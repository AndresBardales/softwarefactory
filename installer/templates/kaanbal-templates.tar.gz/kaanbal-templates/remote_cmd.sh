sudo kubectl get ingress -A
