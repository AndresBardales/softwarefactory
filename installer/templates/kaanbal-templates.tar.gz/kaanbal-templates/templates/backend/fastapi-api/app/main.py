from fastapi import FastAPI

app = FastAPI(title="placeholder-app")


@app.get("/")
async def root():
    return {"message": "placeholder-app is running", "service": "placeholder-app"}


@app.get("/health")
async def health():
    return {"status": "healthy"}
