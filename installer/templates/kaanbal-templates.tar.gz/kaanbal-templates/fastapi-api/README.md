# tpl-fastapi-standard

Template base para APIs REST con FastAPI (Python).

## Características
- FastAPI con Uvicorn
- Health checks configurados
- Ingress HTTPS público
- Sin volumen persistente (stateless API)
- Variables de entorno para conexión a DBs

## Uso
Este template es ideal para:
- APIs REST
- Microservicios backend
- Webhooks y endpoints

## Variables de Entorno Importantes
- `DATABASE_URL`: Conexión a MongoDB/PostgreSQL (ej: `mongodb://user:pass@mi-db.dev.svc.cluster.local:27017`)
- `API_KEY`: Clave de autenticación (configurar en Secret)
