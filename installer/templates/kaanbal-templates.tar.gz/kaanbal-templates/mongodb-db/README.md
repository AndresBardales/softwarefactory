# ==============================================================================
# TPL-MONGODB-STANDARD
# ==============================================================================
# Template para bases de datos MongoDB
# - Volumen persistente (ebs-gp3-retain para no perder datos)
# - SIN Ingress público (solo acceso interno cluster)
# - Autenticación via variables de entorno
# ==============================================================================

# Este template NO requiere pipeline de CI/CD ya que usa la imagen oficial de MongoDB.
# Solo se clona la carpeta k8s/ al infra-gitops para ArgoCD.
