<template>
  <div class="w-full flex justify-center p-4">
    <div class="max-w-2xl w-full bg-gray-800/80 backdrop-blur-md rounded-lg shadow-xl overflow-hidden border border-white/10">
      
      <!-- Header -->
      <div class="px-6 py-6 border-b border-white/10 flex justify-between items-center">
        <div>
           <h1 class="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">Deploy New App</h1>
           <p class="text-gray-400 text-sm mt-1">Configure and launch your application.</p>
        </div>
        <div class="text-right">
            <span class="text-xs text-slate-500 uppercase font-bold tracking-wider">Step {{ step }} of 4</span>
            <div class="flex gap-1 mt-1 justify-end" v-if="step > 1">
              <span v-for="env in allEnvironments" :key="env" :class="['px-2 py-0.5 rounded text-xs font-medium', envBadgeColors[env]]">
                {{ env }}
              </span>
            </div>
        </div>
      </div>

      <!-- Credentials Warning -->
      <div v-if="!credentialsOk && step === 2" class="px-6 py-3 bg-yellow-500/10 border-b border-yellow-500/30 flex items-center gap-3">
        <span class="text-xl">⚠️</span>
        <div class="flex-1">
          <p class="text-yellow-200 text-sm font-medium">Credentials not configured</p>
          <p class="text-yellow-200/70 text-xs">Go to Settings → Credentials to configure Git and Docker before deploying.</p>
        </div>
        <router-link to="/settings" class="text-yellow-400 hover:text-yellow-300 text-sm underline">Configure</router-link>
      </div>

      <!-- Content -->
      <div class="p-8 space-y-6">
        
        <!-- Step 1: Creation Mode Selection -->
        <div v-if="step === 1" class="space-y-6 animate-fade-in">
          <div class="text-center mb-6">
            <h2 class="text-xl font-bold text-white mb-2">How do you want to create your app?</h2>
            <p class="text-slate-400 text-sm">Choose how to set up your project</p>
          </div>

          <div class="grid grid-cols-1 gap-4">
            <!-- Scaffold Mode -->
            <button 
              @click="form.creation_mode = 'scaffold'"
              :class="['p-5 rounded-xl border-2 text-left transition-all', form.creation_mode === 'scaffold' ? 'border-blue-500 bg-blue-500/10' : 'border-white/10 hover:border-white/30 bg-white/5']"
            >
              <div class="flex items-start gap-4">
                <span class="text-3xl">🏗️</span>
                <div class="flex-1">
                  <h3 class="font-bold text-white">Scaffold from Template</h3>
                  <p class="text-sm text-slate-400 mt-1">Create from our battle-tested templates with best practices built-in. Perfect for new projects.</p>
                  <div class="flex gap-2 mt-2">
                    <span class="text-xs px-2 py-1 bg-blue-500/20 text-blue-400 rounded">Recommended</span>
                    <span class="text-xs px-2 py-1 bg-slate-700 text-slate-400 rounded">Vue, FastAPI, n8n...</span>
                  </div>
                </div>
              </div>
            </button>

            <!-- Empty Repo Mode -->
            <button 
              @click="form.creation_mode = 'empty'"
              :class="['p-5 rounded-xl border-2 text-left transition-all', form.creation_mode === 'empty' ? 'border-purple-500 bg-purple-500/10' : 'border-white/10 hover:border-white/30 bg-white/5']"
            >
              <div class="flex items-start gap-4">
                <span class="text-3xl">📁</span>
                <div class="flex-1">
                  <h3 class="font-bold text-white">Empty Repository</h3>
                  <p class="text-sm text-slate-400 mt-1">Create an empty repo with pipeline template. Clone it, add your code, and push.</p>
                  <div class="flex gap-2 mt-2">
                    <span class="text-xs px-2 py-1 bg-purple-500/20 text-purple-400 rounded">Full Control</span>
                    <span class="text-xs px-2 py-1 bg-slate-700 text-slate-400 rounded">Custom Code</span>
                  </div>
                </div>
              </div>
            </button>

            <!-- Config Only Mode -->
            <button 
              @click="form.creation_mode = 'config-only'"
              :class="['p-5 rounded-xl border-2 text-left transition-all', form.creation_mode === 'config-only' ? 'border-emerald-500 bg-emerald-500/10' : 'border-white/10 hover:border-white/30 bg-white/5']"
            >
              <div class="flex items-start gap-4">
                <span class="text-3xl">⚙️</span>
                <div class="flex-1">
                  <h3 class="font-bold text-white">Config Only (No Code)</h3>
                  <p class="text-sm text-slate-400 mt-1">Deploy official Docker images like MongoDB, PostgreSQL, Redis. No code repo needed.</p>
                  <div class="flex gap-2 mt-2">
                    <span class="text-xs px-2 py-1 bg-emerald-500/20 text-emerald-400 rounded">Databases</span>
                    <span class="text-xs px-2 py-1 bg-slate-700 text-slate-400 rounded">Services</span>
                  </div>
                </div>
              </div>
            </button>
          </div>
        </div>
        
        <!-- Step 2: Configuration -->
        <div v-if="step === 2" class="space-y-6 animate-fade-in">
          
          <!-- 🚀 Technology Picker -->
          <div class="space-y-3">
            <label class="block text-sm font-medium text-gray-300">Pick your technology</label>
            <!-- Search + Category Filter -->
            <div class="flex flex-col sm:flex-row gap-2">
              <div class="relative flex-1">
                <span class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm pointer-events-none">🔍</span>
                <input v-model="templateSearch" type="text" placeholder="Search templates..." class="glass-input w-full pl-9 text-sm" />
              </div>
              <div class="flex flex-wrap gap-1 items-center">
                <button type="button" @click="templateCategoryFilter = ''"
                        :class="['px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all border', !templateCategoryFilter ? 'bg-blue-600/20 border-blue-500/50 text-blue-400' : 'border-transparent bg-slate-800/50 text-slate-500 hover:text-slate-300']">
                  All
                </button>
                <button type="button" v-for="cat in availableCategories" :key="cat" @click="templateCategoryFilter = cat"
                        :class="['px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all border capitalize', templateCategoryFilter === cat ? 'bg-blue-600/20 border-blue-500/50 text-blue-400' : 'border-transparent bg-slate-800/50 text-slate-500 hover:text-slate-300']">
                  {{ categoryIcons[cat] || '📦' }} {{ cat }}
                </button>
              </div>
            </div>
            <!-- Template Cards Grid -->
            <div class="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-52 overflow-y-auto custom-scrollbar pr-1">
              <button v-for="tpl in displayedTemplates" :key="tpl.id" type="button" @click="form.template = tpl.id"
                      :class="['p-3 rounded-xl border-2 text-left transition-all group relative overflow-hidden',
                                form.template === tpl.id
                                  ? 'border-blue-500 bg-blue-500/10 shadow-lg shadow-blue-500/10'
                                  : 'border-white/5 hover:border-white/20 bg-slate-900/40 hover:bg-slate-800/60']">
                <div class="absolute top-0 left-0 right-0 h-0.5 opacity-80" :style="{ background: tpl.color || '#6366f1' }"></div>
                <div class="flex items-center gap-2 mb-1.5">
                  <span class="text-base" :style="{ filter: form.template === tpl.id ? 'drop-shadow(0 0 6px ' + (tpl.color || '#6366f1') + ')' : 'none' }">{{ getTemplateIcon(tpl.icon) }}</span>
                  <h4 class="text-xs font-bold text-white truncate flex-1">{{ tpl.name }}</h4>
                  <span v-if="tpl.popular" class="text-[8px] leading-none">⭐</span>
                </div>
                <p class="text-[10px] text-slate-500 line-clamp-2 mb-1.5 leading-tight">{{ tpl.description }}</p>
                <div class="flex flex-wrap gap-0.5">
                  <span v-for="tech in (tpl.stack || []).slice(0, 3)" :key="tech"
                        class="text-[8px] px-1 py-0.5 rounded bg-slate-800/80 text-slate-400">{{ tech }}</span>
                  <span v-if="tpl.status !== 'ready'" class="text-[8px] px-1 py-0.5 rounded bg-yellow-500/10 text-yellow-500">{{ tpl.status }}</span>
                </div>
              </button>
            </div>
            <p v-if="displayedTemplates.length === 0" class="text-center text-xs text-slate-500 py-3">No templates match your criteria.</p>
            <!-- Selected template indicator -->
            <div v-if="selectedTemplate" class="flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-500/5 border border-blue-500/20 transition-all">
              <span>{{ getTemplateIcon(selectedTemplate.icon) }}</span>
              <span class="text-sm text-blue-400 font-medium">{{ selectedTemplate.name }}</span>
              <span class="text-[10px] text-slate-500 uppercase tracking-wider">selected</span>
            </div>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
              <!-- Name & Environments -->
              <div class="space-y-4">
                  <div>
                    <label class="block text-sm font-medium text-gray-300 mb-1">Application Name</label>
                    <input v-model="form.name" type="text" class="glass-input w-full" :disabled="useRootDomain" placeholder="e.g. customer-portal" required />
                    <p class="text-xs text-slate-500 mt-1">Lowercase, hyphens only.</p>
                    <label v-if="supportsRootDomain" class="mt-2 flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                      <input type="checkbox" v-model="useRootDomain" class="w-4 h-4 rounded bg-slate-700 border-slate-600" />
                      <span>Use root domain in prod (<code>https://{{ rootDomainHost }}</code>) and assign internal name <code>homepage</code> automatically.</span>
                    </label>
                    <p v-else-if="existingRootApp && selectedTemplate?.category === 'frontend'" class="mt-2 text-xs text-amber-400/80">
                      ⚠️ Root domain is already assigned to <span class="font-mono font-semibold">{{ existingRootApp }}</span>. Only one root-domain app is allowed.
                    </p>
                  </div>

                  <!-- Multi-Environment Selector (Prod is always included, can add dev/staging) -->
                  <div>
                    <label class="block text-sm font-medium text-gray-300 mb-2">Additional Environments <span class="text-slate-500">(prod always included)</span></label>
                    <div class="space-y-2">
                        <label class="flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all"
                               :class="form.environments.includes('dev') ? 'bg-yellow-500/20 border border-yellow-500/30' : 'bg-slate-900/50 border border-transparent hover:border-slate-600'">
                            <input type="checkbox" value="dev" v-model="form.environments" class="w-4 h-4 rounded bg-slate-700 border-slate-600" />
                            <span class="text-lg">🧪</span>
                            <div class="flex-1">
                                <span class="text-white font-medium">+ Development</span>
                                <p class="text-xs text-slate-400">For testing and development</p>
                            </div>
                        </label>
                        <label class="flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all"
                               :class="form.environments.includes('staging') ? 'bg-orange-500/20 border border-orange-500/30' : 'bg-slate-900/50 border border-transparent hover:border-slate-600'">
                            <input type="checkbox" value="staging" v-model="form.environments" class="w-4 h-4 rounded bg-slate-700 border-slate-600" />
                            <span class="text-lg">🔬</span>
                            <div class="flex-1">
                                <span class="text-white font-medium">+ Staging</span>
                                <p class="text-xs text-slate-400">Pre-production testing</p>
                            </div>
                        </label>
                        <!-- Prod is ALWAYS included (shown as always-on) -->
                        <div class="flex items-center gap-3 p-3 rounded-lg bg-emerald-500/20 border border-emerald-500/30">
                            <input type="checkbox" checked disabled class="w-4 h-4 rounded bg-emerald-600 border-emerald-500 cursor-not-allowed" />
                            <span class="text-lg">🚀</span>
                            <div class="flex-1">
                                <span class="text-white font-medium">Production</span>
                                <span class="text-xs text-emerald-400 ml-2">(always included)</span>
                                <p class="text-xs text-slate-400">Live environment</p>
                            </div>
                        </div>
                    </div>
                  </div>
              </div>

              <!-- Specs -->
              <div class="space-y-4">
                  <div>
                    <label class="block text-sm font-medium text-gray-300 mb-1">Exposure per Environment</label>
                    <p v-if="exposureHint" class="text-xs text-amber-400/80 mb-2 flex items-center gap-1">
                      <span>💡</span> {{ exposureHint }}
                    </p>

                    <!-- ── MULTI-PORT MODE: port × env matrix ── -->
                    <div v-if="isMultiPort" class="space-y-3">
                      <p class="text-xs text-blue-400/80 flex items-center gap-1 mb-1">
                        📡 This template exposes <strong class="text-blue-300">{{ templatePorts.length }} ports</strong> — set each as public or private per environment.
                      </p>
                      <div class="overflow-x-auto">
                        <table class="w-full text-[11px]">
                          <thead>
                            <tr class="border-b border-white/10">
                              <th class="text-left text-slate-500 font-medium py-1.5 pr-2 w-32">Port</th>
                              <th v-for="env in allEnvironments" :key="'th-' + env"
                                  class="text-center py-1.5 px-1">
                                <span :class="['text-[10px] px-2.5 py-0.5 rounded font-bold', envBadgeColors[env]]">{{ env }}</span>
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="p in templatePorts" :key="p.name" class="border-b border-white/5">
                              <td class="py-2.5 pr-2">
                                <div class="flex flex-col">
                                  <span class="text-white font-semibold text-xs">{{ p.name }}</span>
                                  <span class="text-slate-600 text-[9px]">:{{ p.port }} {{ p.protocol }}</span>
                                  <span v-if="p.description" class="text-slate-700 text-[8px] truncate max-w-[110px]">{{ p.description }}</span>
                                </div>
                              </td>
                              <td v-for="env in allEnvironments" :key="env + '-' + p.name" class="py-1.5 px-0.5">
                                <div class="flex flex-col gap-[3px]">
                                  <button v-for="mode in portExposureModes" :key="mode.value"
                                      type="button" @click="setPortExposure(env, p.name, mode.value)"
                                      :class="['px-1.5 py-[3px] rounded border transition-all text-center block w-full text-[10px] font-medium',
                                                 getPortExposure(env, p.name) === mode.value
                                                   ? mode.activeClass
                                                   : 'bg-slate-900/50 border-slate-800/50 text-slate-600 hover:border-slate-600 hover:text-slate-400']">
                                      {{ mode.icon }} {{ mode.label }}
                                  </button>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <!-- ── SIMPLE MODE: single exposure per env ── -->
                    <div v-else class="space-y-1.5">
                      <div v-for="env in allEnvironments" :key="'exp-' + env" class="flex items-center gap-2 p-1.5 rounded-lg bg-slate-900/30 border border-white/5">
                        <span :class="['text-[10px] font-bold px-2 py-0.5 rounded w-16 text-center shrink-0', envBadgeColors[env]]">{{ env }}</span>
                        <!-- Root-domain apps: prod is always public (locked) -->
                        <div v-if="useRootDomain && env === 'prod'" class="flex gap-1 flex-1">
                          <span class="px-2 py-1 rounded text-[11px] border flex-1 text-center bg-blue-600 border-blue-500 text-white cursor-not-allowed opacity-80">
                            🌐 Public (root domain)
                          </span>
                        </div>
                        <div v-else class="flex gap-1 flex-1">
                          <button v-for="mode in availableExposureModes" :key="mode.value"
                              type="button" @click="setEnvExposure(env, mode.value)"
                              :class="['px-2 py-1 rounded text-[11px] border transition-all flex-1 text-center',
                                         getEnvExposure(env) === mode.value
                                           ? 'bg-blue-600 border-blue-500 text-white'
                                           : 'bg-slate-900/50 border-slate-700/50 text-slate-500 hover:border-slate-500 hover:text-slate-300']">
                              {{ mode.icon }} {{ mode.label }}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label class="block text-sm font-medium text-gray-300 mb-1">Replicas</label>
                    <input v-model.number="form.specs.replicas" type="number" min="1" max="5" class="glass-input w-full" />
                  </div>
              </div>
          </div>

          <div>
             <label class="block text-sm font-medium text-gray-300 mb-1">Description</label>
             <textarea v-model="form.description" rows="3" class="glass-input w-full" placeholder="What does this app do?"></textarea>
          </div>

          <!-- Dynamic Template Configuration -->
          <div v-if="templateSchema" class="pt-4 border-t border-white/10 mt-4 animate-fade-in">
              <h3 class="text-sm font-medium text-blue-400 mb-4 flex items-center gap-2">
                <span>⚡</span> Template Configuration
              </h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div v-for="(field, key) in templateSchema" :key="key">
                    <label class="block text-sm font-medium text-gray-300 mb-1 capitalize">{{ field.label || key.replace(/_/g, ' ') }}</label>
                      
                      <!-- Select -->
                      <div v-if="field.type === 'select'" class="relative">
                        <select v-model="form.template_config[key]" class="glass-input w-full appearance-none cursor-pointer">
                            <option v-for="opt in field.options" :key="opt" :value="opt">{{ opt }}</option>
                        </select>
                        <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none text-slate-400">
                          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                        </div>
                      </div>
                      
                      <!-- Number -->
                      <input v-else-if="field.type === 'number'" type="number" 
                            v-model.number="form.template_config[key]" 
                            :min="field.min" :max="field.max"
                            class="glass-input w-full" />
                            
                      <!-- Checkbox (Boolean) -->
                      <label v-else-if="field.type === 'boolean'" class="flex items-center gap-3 p-3 rounded-lg bg-slate-900/50 border border-white/5 cursor-pointer">
                          <input type="checkbox" v-model="form.template_config[key]" class="rounded bg-slate-700 border-slate-600 text-blue-500" />
                          <span class="text-sm text-slate-300">{{ field.label || key.replace(/_/g, ' ') }}</span>
                      </label>

                      <!-- String/Default -->
                      <input v-else type="text" v-model="form.template_config[key]" class="glass-input w-full" />
                      
                      <p v-if="field.description" class="text-xs text-slate-500 mt-1">{{ field.description }}</p>
                  </div>
              </div>
          </div>

        </div>

        <!-- Step 2: Review -->
        <div v-if="step === 3" class="space-y-4 animate-fade-in">
             <!-- Creation Mode Badge -->
             <div :class="['rounded-lg p-4 border', creationModeBadge.classes]">
                <div class="flex items-center gap-3">
                  <span class="text-2xl">{{ creationModeBadge.icon }}</span>
                  <div>
                    <h3 :class="['font-semibold', creationModeBadge.textClass]">{{ creationModeBadge.title }}</h3>
                    <p class="text-sm text-slate-400">{{ creationModeBadge.description }}</p>
                  </div>
                </div>
             </div>

             <div class="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                <h3 class="text-blue-400 font-semibold mb-2">Summary</h3>
                <dl class="grid grid-cols-2 gap-4 text-sm">
                    <div class="col-span-1">
                        <dt class="text-slate-500">Name</dt>
                        <dd class="text-white font-medium">{{ form.name }}</dd>
                    </div>
                     <div class="col-span-1">
                        <dt class="text-slate-500">Template</dt>
                        <dd class="text-white font-medium">{{ selectedTemplate?.name || form.template }}</dd>
                    </div>
                     <div class="col-span-2">
                        <dt class="text-slate-500 mb-2">Environments</dt>
                        <dd class="flex gap-2">
                            <span v-for="env in allEnvironments" :key="env" 
                                  :class="['px-3 py-1 rounded-lg text-sm font-medium', envBadgeColors[env]]">
                                {{ envLabels[env] }}
                            </span>
                        </dd>
                    </div>
                     <div class="col-span-1">
                        <dt class="text-slate-500 mb-1">Exposure</dt>
                        <dd class="space-y-1">
                          <!-- Multi-port exposure summary -->
                          <template v-if="isMultiPort && form.exposure.port_exposure">
                            <div v-for="env in allEnvironments" :key="'rev-mp-' + env" class="mb-2">
                              <div class="flex items-center gap-1.5 mb-1">
                                <span :class="['text-[9px] font-bold px-1.5 py-0.5 rounded', envBadgeColors[env]]">{{ env }}</span>
                              </div>
                              <div class="ml-5 space-y-0.5">
                                <div v-for="p in templatePorts" :key="p.name" class="flex items-center gap-2 text-[10px]">
                                  <span class="text-slate-500 w-20 truncate">{{ p.name }} :{{ p.port }}</span>
                                  <span :class="['px-1.5 py-0.5 rounded text-[9px] font-medium',
                                    getPortExposure(env, p.name) === 'public' ? 'bg-emerald-500/20 text-emerald-400' :
                                    getPortExposure(env, p.name) === 'tailscale' ? 'bg-purple-500/20 text-purple-400' :
                                    'bg-slate-500/20 text-slate-400']">
                                    {{ getPortExposure(env, p.name) === 'tailscale' ? 'Private' : getPortExposure(env, p.name) }}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </template>
                          <!-- Simple exposure summary -->
                          <template v-else>
                            <div v-for="env in allEnvironments" :key="'rev-' + env" class="flex items-center gap-1.5">
                              <span :class="['text-[9px] font-bold px-1.5 py-0.5 rounded', envBadgeColors[env]]">{{ env }}</span>
                              <span class="text-white text-xs capitalize">{{ getEnvExposure(env) }}</span>
                            </div>
                          </template>
                        </dd>
                    </div>
                     <div class="col-span-1">
                        <dt class="text-slate-500">Scale</dt>
                        <dd class="text-white font-medium">{{ form.specs.replicas }} Pods per env</dd>
                    </div>

                    <!-- Dynamic Config Summary -->
                    <div v-if="Object.keys(form.template_config).length > 0" class="col-span-2 pt-2 border-t border-blue-500/20 mt-2">
                       <dt class="text-slate-500 mb-2">Template Configuration</dt>
                       <dd class="grid grid-cols-2 gap-2">
                           <div v-for="(val, key) in form.template_config" :key="key" class="bg-slate-900/50 px-3 py-1.5 rounded border border-white/5 flex flex-col">
                               <span class="text-[10px] text-slate-500 uppercase font-bold tracking-wider">{{ key.replace(/_/g, ' ') }}</span>
                               <span class="text-white font-mono text-xs">{{ val }}</span>
                           </div>
                       </dd>
                    </div>
                </dl>
             </div>
             
             <div class="flex items-center gap-3 p-4 bg-slate-900/50 rounded-lg border border-slate-700/50">
                 <div class="text-2xl">🚀</div>
                 <div>
                     <p class="text-white text-sm font-medium">Ready to Deploy to {{ allEnvironments.length }} environment(s)?</p>
                     <p class="text-slate-400 text-xs" v-if="form.creation_mode === 'scaffold'">This will create the repository with template code, pipeline, and GitOps manifests.</p>
                     <p class="text-slate-400 text-xs" v-else-if="form.creation_mode === 'empty'">This will create an empty repo. After deploy, clone it, add your code, and push to trigger the pipeline.</p>
                     <p class="text-slate-400 text-xs" v-else>This will create GitOps manifests and deploy the official Docker image.</p>
                 </div>
             </div>

             <!-- Instructions for Empty Mode -->
             <div v-if="form.creation_mode === 'empty'" class="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                <h4 class="text-purple-400 font-semibold mb-2 flex items-center gap-2">
                  <span>📋</span> Next Steps After Deploy
                </h4>
                <ol class="text-sm text-slate-300 space-y-2 list-decimal list-inside">
                  <li>Clone the repository: <code class="bg-slate-800 px-2 py-1 rounded text-xs">git clone {{ repoCloneUrl }}</code></li>
                  <li>Add your code and a Dockerfile</li>
                  <li>Push to main branch to trigger the pipeline</li>
                  <li>The pipeline will build and deploy automatically</li>
                </ol>
             </div>
        </div>

        <!-- Step 3: Deployment Progress with Terminal -->
        <div v-if="step === 4" class="w-full">
             <div class="text-center mb-6">
                 <h3 class="text-xl font-bold text-white mb-2">Deploying {{ form.name }}...</h3>
                 <p class="text-slate-400 text-sm">Initializing factory workers and building your app.</p>
             </div>

             <!-- Terminal Window -->
             <div class="bg-[#0d1117] rounded-lg border border-slate-700 overflow-hidden font-mono text-xs md:text-sm shadow-2xl">
                 <!-- Terminal Header -->
                 <div class="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700">
                     <div class="flex gap-2">
                         <div class="w-3 h-3 rounded-full bg-red-500"></div>
                         <div class="w-3 h-3 rounded-full bg-yellow-500"></div>
                         <div class="w-3 h-3 rounded-full bg-green-500"></div>
                     </div>
                     <div class="text-slate-400 text-xs">kaanbal-engine-cli — node</div>
                     <div></div>
                 </div>
                 
                 <!-- Terminal Body -->
                 <div class="p-4 h-64 overflow-y-auto space-y-2" ref="terminalBody">
                     <div v-for="(log, index) in deployLogs" :key="index" class="font-mono">
                         <span class="text-slate-500">[{{ log.time }}]</span>
                         <span :class="log.color || 'text-slate-300'"> {{ log.message }}</span>
                     </div>
                     <div v-if="loading" class="animate-pulse text-blue-400">_</div>
                 </div>
             </div>
        </div>

         <!-- Step 4: Success -->
        <div v-if="step === 5" class="text-center py-8">
             <div class="mb-6 text-6xl">✨</div>
             <h3 class="text-xl font-bold text-white mb-2">
               {{ form.creation_mode === 'empty' ? 'Repository Created!' : 'Deployed Successfully!' }}
             </h3>
             <p class="text-slate-400 mb-6">
               {{ form.creation_mode === 'empty' 
                  ? 'Clone the repo, add your code, and push to deploy.' 
                  : 'Your app is now provisioning in the cluster.' }}
             </p>
             
             <!-- Empty mode: show clone command -->
             <div v-if="form.creation_mode === 'empty' && deployResult?.repo_url" class="max-w-md mx-auto mb-6 bg-slate-800 rounded-lg p-4 text-left">
               <p class="text-xs text-slate-500 mb-2">Clone command:</p>
               <code class="text-sm text-emerald-400 break-all">git clone {{ deployResult.repo_url }}</code>
             </div>
             
             <div class="flex justify-center gap-4">
                 <router-link to="/apps" class="glass-button bg-slate-700 hover:bg-slate-600">View Apps</router-link>
                 <a v-if="deployResult?.repo_url" :href="deployResult.repo_url.replace('.git', '')" target="_blank" class="glass-button">View Repository</a>
             </div>
        </div>

      </div>

      <!-- Footer -->
      <div v-if="step < 4" class="px-6 py-4 bg-black/20 border-t border-white/10 flex justify-between items-center">
         <button v-if="step > 1" @click="step--" class="text-gray-400 hover:text-white px-4 py-2 transition-colors">Back</button>
         <div v-else></div>

         <button v-if="step === 1" @click="nextStep" :disabled="!form.creation_mode" class="glass-button disabled:opacity-50 disabled:cursor-not-allowed">Next</button>
         <button v-if="step === 2" @click="nextStep" :disabled="!isFormValid" class="glass-button disabled:opacity-50 disabled:cursor-not-allowed">Next</button>
         <button v-if="step === 3" @click="deploy" :disabled="loading" class="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white px-8 py-2.5 rounded-lg font-bold shadow-lg shadow-blue-900/20 transform hover:-translate-y-0.5 transition-all flex items-center">
            <span v-if="loading" class="animate-spin mr-2">⚙️</span>
            {{ loading ? 'Igniting...' : 'Launch App' }}
         </button>
      </div>
      
      <!-- Error Message -->
      <div v-if="errorMessage" class="p-4 bg-red-900/50 border-t border-red-500/20 text-center text-sm font-medium text-red-200">
          {{ errorMessage.replace(/https:\/\/[^@]+@/g, 'https://***@') }}
      </div>

    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue'
import axios from 'axios'
import { getConfig } from '@/config'
import { useRouter, useRoute } from 'vue-router'

const router = useRouter()
const route = useRoute()

const step = ref(1)
const loading = ref(false)
const loadingTemplates = ref(true)
const errorMessage = ref('')
const deployResult = ref(null)
const credentialsOk = ref(true)
const templates = ref([])
const deployLogs = ref([])
const terminalBody = ref(null)
const templateSearch = ref('')
const templateCategoryFilter = ref('')
const useRootDomain = ref(false)
const existingRootApp = ref(null)  // Track if a root-domain app already exists

// Environment config
const envLabels = { dev: 'Development', staging: 'Staging', prod: 'Production' }
const envColors = { dev: 'text-yellow-400', staging: 'text-orange-400', prod: 'text-emerald-400' }
const envBadgeColors = {
    dev: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30',
    staging: 'bg-orange-500/20 text-orange-400 border border-orange-500/30',
    prod: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
}
const envDescriptions = {
    dev: 'For testing and development. Changes can be made freely.',
    staging: 'Pre-production testing. Mirror of production environment.',
    prod: 'Live production environment. Handle with care.'
}

const form = reactive({
    name: '',
    template: '',
    description: '',
    creation_mode: 'scaffold',  // scaffold, empty, config-only
    template_config: {},
    environments: [],  // Additional envs (dev, staging) - prod is always added automatically
    specs: {
        replicas: 1,
        port: 80,
        resources: {
            cpu_request: "100m",
            cpu_limit: "500m",
            mem_request: "128Mi",
            mem_limit: "512Mi"
        }
    },
    exposure: {
        type: 'internal',
        public_path: '/',
        tailscale_hostname: null,
        per_env: {},
        // Multi-port support
        ports: null,          // [{name,port,protocol,description}] from template
        port_exposure: null   // { env: { portName: 'public'|'tailscale'|... } }
    }
})

// Computed: all environments (prod + selected additional)
const allEnvironments = computed(() => {
    // prod is ALWAYS included, plus any additional selected
    const envs = [...form.environments]
    if (!envs.includes('prod')) {
        envs.push('prod')
    }
    // Sort: dev, staging, prod
    return envs.sort((a, b) => {
        const order = { dev: 0, staging: 1, prod: 2 }
        return order[a] - order[b]
    })
})

  const repoCloneUrl = computed(() => {
    const name = form.name || '<app-name>'
    const provider = getConfig('gitProvider', 'bitbucket')
    const namespace = getConfig('gitNamespace', '')

    if (provider === 'github') {
      const org = namespace || '<org>'
      return `https://github.com/${org}/${name}.git`
    }

    const workspace = namespace || '<workspace>'
    return `https://bitbucket.org/${workspace}/${name}.git`
  })

// Computed for selected template details
const selectedTemplate = computed(() => {
    return templates.value.find(t => t.id === form.template)
})

// Computed for creation mode badge
const creationModeBadge = computed(() => {
    const modes = {
        'scaffold': {
            icon: '🏗️',
            title: 'Scaffold from Template',
            description: 'Will create repo with template code and configured pipeline',
            classes: 'bg-blue-500/10 border-blue-500/30',
            textClass: 'text-blue-400'
        },
        'empty': {
            icon: '📁',
            title: 'Empty Repository',
            description: 'Will create empty repo - you clone, add code, and push',
            classes: 'bg-purple-500/10 border-purple-500/30',
            textClass: 'text-purple-400'
        },
        'config-only': {
            icon: '⚙️',
            title: 'Config Only (No Code)',
            description: 'Will deploy using official Docker image - no code repo',
            classes: 'bg-emerald-500/10 border-emerald-500/30',
            textClass: 'text-emerald-400'
        }
    }
    return modes[form.creation_mode] || modes['scaffold']
})

// Computed for selected template schema
const templateSchema = computed(() => {
    if (!selectedTemplate.value || !selectedTemplate.value.config_schema) return null
    return selectedTemplate.value.config_schema
})

// All possible exposure modes with labels
const allExposureModes = {
    public:    { value: 'public',    label: 'Public',   icon: '🌐' },
    tailscale: { value: 'tailscale', label: 'VPN',      icon: '🔒' },
    internal:  { value: 'internal',  label: 'Internal', icon: '🏠' },
    both:      { value: 'both',      label: 'Both',     icon: '🔀' }
}

// Simplified exposure modes for multi-port matrix (per-port level)
const portExposureModes = [
    { value: 'public',    label: 'Public',   icon: '🌐', activeClass: 'bg-emerald-600 border-emerald-500 text-white' },
    { value: 'tailscale', label: 'Private',  icon: '🔒', activeClass: 'bg-purple-600 border-purple-500 text-white' },
    { value: 'internal',  label: 'Internal', icon: '🏠', activeClass: 'bg-slate-600 border-slate-500 text-white' }
]

// Computed: available exposure modes based on selected template's category
const availableExposureModes = computed(() => {
    const tpl = selectedTemplate.value
    if (!tpl) return [allExposureModes.internal, allExposureModes.public, allExposureModes.tailscale]
    
    // Check if template has its own exposure rules
    if (tpl.exposure?.mode) {
        // Template has explicit exposure — show only that
        const mode = tpl.exposure.mode
        return [allExposureModes[mode]].filter(Boolean)
    }
    
    // Find category definition from templates list
    // Category-based exposure rules (standardized)
    // frontend:   public or VPN (internal makes no sense for a UI)
    // backend:    internal, VPN, or public (full flexibility)
    // database:   internal or VPN (never expose publicly)
    // monitoring: VPN only (admin tools)
    // devtools:   VPN only (admin tools)
    // workflow:   VPN or public (webhooks may need public)
    // iot:        all options (sensors/gateways have diverse needs)
    // Per-environment model: each env selects ONE mode. 'both' is auto-computed when
    // envs are mixed — it is NOT a selectable option. Keep options simple and atomic.
    const categoryDefaults = {
        database:   ['internal', 'tailscale'],          // DBs: never public
        monitoring: ['tailscale'],                      // Admin tools: VPN only
        devtools:   ['tailscale'],                      // Admin tools: VPN only
        workflow:   ['tailscale', 'public'],            // n8n: webhooks=public, UI=VPN
        frontend:   ['public', 'tailscale'],            // UIs: public or VPN (no internal)
        backend:    ['internal', 'tailscale', 'public'], // APIs: all 3 single modes
        iot:        ['internal', 'tailscale', 'public'], // IoT: all 3 single modes
        messaging:  ['internal', 'tailscale', 'public']  // MQTT/messaging: per-port control via matrix
    }
    
    const category = tpl.category
    const allowed = categoryDefaults[category] || ['internal', 'public', 'tailscale']
    return allowed.map(m => allExposureModes[m]).filter(Boolean)
})

// Computed: hint text for exposure
const exposureHint = computed(() => {
    const tpl = selectedTemplate.value
    if (!tpl) return ''
    
    const hints = {
        database: 'Databases should stay internal or VPN. Never expose publicly.',
        monitoring: 'Monitoring tools should be VPN only.',
        devtools: 'Admin tools should be VPN only.',
        workflow: 'Webhook endpoints can be public, but UI should stay VPN.',
        frontend: 'Frontends are public or VPN. Internal access has no use for a UI.',
        backend: 'APIs can be internal (cluster only), VPN (private access), or public.',
        messaging: 'MQTT ports can be public for devices. Dashboard should stay VPN (Tailscale).'
    }
    return hints[tpl.category] || ''
})

// Template icon mapping
const getTemplateIcon = (iconId) => {
    const icons = {
      vue: '🟢', react: '⚛️', angular: '🅰️', next: '▲',
      python: '🐍', nodejs: '💚', nestjs: '🔺', laravel: '🔻',
      django: '🟤', flask: '⚗️', go: '🔵',
      mongodb: '🍃', mysql: '🐬', postgres: '🐘', redis: '🔴',
      n8n: '🔄', grafana: '📊', mosquitto: '📡', emqx: '📡'
    }
    return icons[iconId] || '📦'
}

const categoryIcons = {
    frontend: '🎨', backend: '⚙️', database: '💾', workflow: '🔄',
    iot: '📡', monitoring: '📊', devtools: '🛠️', fullstack: '📚', messaging: '📡'
}

const rootDomainHost = computed(() => {
  const configured = getConfig('domain', '')
  if (configured) return configured
  return window.location.hostname.replace(/^kaanbal-console\./, '')
})

const supportsRootDomain = computed(() => {
  const category = selectedTemplate.value?.category
  return category === 'frontend' && !existingRootApp.value
})

// Available categories from filtered templates
const availableCategories = computed(() => {
    const cats = [...new Set(filteredTemplates.value.map(t => t.category).filter(Boolean))]
    const order = ['frontend', 'backend', 'database', 'workflow', 'iot', 'monitoring', 'devtools']
    return cats.sort((a, b) => (order.indexOf(a) === -1 ? 99 : order.indexOf(a)) - (order.indexOf(b) === -1 ? 99 : order.indexOf(b)))
})

// Templates filtered by search + category filter
const displayedTemplates = computed(() => {
    let tpls = filteredTemplates.value
    if (templateCategoryFilter.value) {
        tpls = tpls.filter(t => t.category === templateCategoryFilter.value)
    }
    if (templateSearch.value) {
        const q = templateSearch.value.toLowerCase()
        tpls = tpls.filter(t =>
            t.name?.toLowerCase().includes(q) ||
            t.description?.toLowerCase().includes(q) ||
            t.stack?.some(s => s.toLowerCase().includes(q)) ||
            t.category?.toLowerCase().includes(q)
        )
    }
    return tpls.sort((a, b) => {
        if (a.status === 'ready' && b.status !== 'ready') return -1
        if (b.status === 'ready' && a.status !== 'ready') return 1
        if (a.popular && !b.popular) return -1
        if (b.popular && !a.popular) return 1
        return (a.name || '').localeCompare(b.name || '')
    })
})

// Per-environment exposure helpers
const setEnvExposure = (env, type) => {
    if (!form.exposure.per_env) form.exposure.per_env = {}
    form.exposure.per_env[env] = type
}

const getEnvExposure = (env) => {
    return form.exposure.per_env?.[env] || form.exposure.type || 'internal'
}

// Multi-port support
const isMultiPort = computed(() => {
    const tpl = selectedTemplate.value
    return tpl?.ports && tpl.ports.length > 1
})

const templatePorts = computed(() => {
    return selectedTemplate.value?.ports || []
})

const setPortExposure = (env, portName, type) => {
    if (!form.exposure.port_exposure) form.exposure.port_exposure = {}
    if (!form.exposure.port_exposure[env]) form.exposure.port_exposure[env] = {}
    form.exposure.port_exposure[env][portName] = type
}

const getPortExposure = (env, portName) => {
    return form.exposure.port_exposure?.[env]?.[portName] || getEnvExposure(env)
}

// Initialize config when template changes
watch(() => form.template, (newVal) => {
    // Reset config
    form.template_config = {}
    
    // Initialize defaults from schema
    if (newVal && templateSchema.value) {
        Object.entries(templateSchema.value).forEach(([key, field]) => {
            if (field.default !== undefined) {
                form.template_config[key] = field.default
            }
        })
    }
    
    // Set smart exposure default based on category
    const tpl = selectedTemplate.value
    if (tpl) {
        // Sync specs.port from template catalog (e.g. 8000 for FastAPI, 80 for Vue)
        if (tpl.port) {
            form.specs.port = tpl.port
        }

        // Prod-level default (what you'd expose to the world)
        const categoryExposureDefaults = {
            database: 'internal',
            monitoring: 'tailscale',
            devtools: 'tailscale',
            workflow: 'tailscale',
            frontend: 'public',
            backend: 'public',
            iot: 'tailscale',
            messaging: 'tailscale'
        }
        const defaultExposure = categoryExposureDefaults[tpl.category] || 'internal'
        form.exposure.type = defaultExposure

        // Smart per-env defaults:
        // - prod: category default (public for frontend/backend, internal for DB, etc.)
        // - dev/staging: VPN for web apps (frontend/backend), same as prod for infra
        form.exposure.per_env = {}
        const nonProdOverride = ['frontend', 'backend'].includes(tpl.category) ? 'tailscale' : null
        allEnvironments.value.forEach(env => {
            if (nonProdOverride && env !== 'prod') {
                form.exposure.per_env[env] = nonProdOverride
            } else {
                form.exposure.per_env[env] = defaultExposure
            }
        })
        
        // Multi-port: populate ports and port_exposure from template
        if (tpl.ports && tpl.ports.length > 1) {
            form.exposure.ports = tpl.ports
            form.exposure.port_exposure = {}
            allEnvironments.value.forEach(env => {
                form.exposure.port_exposure[env] = {}
                tpl.ports.forEach(p => {
                    // Support per-env format: port_defaults.{env}.{portName}
                    // Fallback to flat format: port_defaults.{portName}
                    const perEnv = tpl.port_defaults?.[env]?.[p.name]
                    const flat = tpl.port_defaults?.[p.name]
                    form.exposure.port_exposure[env][p.name] = perEnv || flat || defaultExposure
                })
            })
        } else {
            form.exposure.ports = null
            form.exposure.port_exposure = null
        }
    }
    
    // Don't auto-override creation_mode — user already chose it in step 1
    // Only override if current mode isn't supported by this template
    if (tpl && tpl.creation_modes && tpl.creation_modes.length > 0) {
       if (!tpl.creation_modes.includes(form.creation_mode)) {
           form.creation_mode = tpl.creation_modes[0]
       }
    }

    if (!supportsRootDomain.value) {
      useRootDomain.value = false
    }
})

  watch(useRootDomain, (enabled) => {
    if (!enabled) return
    // Internal unique suffix (if needed) is allocated server-side.
    form.name = 'homepage'
    // Root-domain apps MUST have prod exposed as public (it IS the root domain).
    if (!form.exposure.per_env) form.exposure.per_env = {}
    form.exposure.per_env.prod = 'public'
  })

// Watch environments to auto-populate per_env for new envs
watch(() => [...form.environments], () => {
    if (!form.exposure.per_env) form.exposure.per_env = {}
    allEnvironments.value.forEach(env => {
        if (!(env in form.exposure.per_env)) {
            form.exposure.per_env[env] = form.exposure.type || 'internal'
        }
    })
    // Also populate port_exposure for multi-port templates
    if (form.exposure.ports && form.exposure.port_exposure) {
        allEnvironments.value.forEach(env => {
            if (!form.exposure.port_exposure[env]) {
                form.exposure.port_exposure[env] = {}
                form.exposure.ports.forEach(p => {
                    form.exposure.port_exposure[env][p.name] = form.exposure.type || 'internal'
                })
            }
        })
    }
}, { deep: true })

onMounted(async () => {
    // Load templates from API
    try {
        const { data } = await axios.get('/api/v1/templates')
        templates.value = data
    } catch (e) {
        console.error('Failed to load templates:', e)
    } finally {
        loadingTemplates.value = false
    }

    // Check if a root-domain app already exists (only one allowed)
    try {
        const { data } = await axios.get('/api/v1/apps')
        const found = data.find(a => a.is_root_domain)
        if (found) existingRootApp.value = found.name
    } catch (e) {
        // Non-critical — supportsRootDomain stays false if we can't check
    }
    
    // Check for pre-selected template from query
    if (route.query.template) {
        form.template = route.query.template
    }
    
    // Check credentials status
    try {
        const { data } = await axios.get('/api/v1/system/credentials/status')
        credentialsOk.value = data.configured
    } catch (e) {
        console.warn('Could not check credentials status')
    }
})

const isFormValid = computed(() => {
    return form.name.length > 2 && form.template
})

// Filtered templates based on selected creation mode
const filteredTemplates = computed(() => {
    if (!templates.value.length) return []
    return templates.value.filter(t => {
        if (!t.creation_modes) return true
        // Map 'config-only' to 'config-only' in template's creation_modes array
        return t.creation_modes.includes(form.creation_mode)
    })
})

const nextStep = () => {
    if (step.value === 1) {
        // Step 1 only needs a creation mode selected
        if (form.creation_mode) {
            // Reset template when changing step (mode may have changed)
            form.template = ''
            form.template_config = {}
            templateSearch.value = ''
            templateCategoryFilter.value = ''
            step.value++
        }
    } else if (step.value === 2) {
        if (isFormValid.value) step.value++
    } else {
        step.value++
    }
}

const addLog = (message, color = 'text-slate-300') => {
    const time = new Date().toLocaleTimeString('en-US', { hour12: false })
    // Sanitize: strip any credential/token patterns that might leak
    let safeMsg = message
        .replace(/https:\/\/[^@]+@/g, 'https://***@')
        .replace(/ATATT[A-Za-z0-9_=-]+/g, '***')
        .replace(/:[A-Za-z0-9_=-]{20,}@/g, ':***@')
    deployLogs.value.push({ time, message: safeMsg, color })
    // Auto scroll
    setTimeout(() => {
        if (terminalBody.value) {
            terminalBody.value.scrollTop = terminalBody.value.scrollHeight
        }
    }, 10)
}

const deploy = async () => {
    loading.value = true
    errorMessage.value = ''
    step.value = 4
    deployLogs.value = []

    addLog('Initializing deployment sequence...')
    addLog(`Target: ${form.name} (${allEnvironments.value.join(', ')})`)

    try {
        // Build payload
        const payload = {
            ...form,
            category: selectedTemplate.value?.category || null,
            environments: allEnvironments.value,
          creation_mode: form.creation_mode,
          template_config: {
            ...(form.template_config || {}),
            use_root_domain: useRootDomain.value
          }
        }

        // Step 1: Create app (returns immediately with app_id + stream_url)
        const response = await axios.post('/api/v1/apps', payload)
        const { id: appId, stream_url } = response.data
        deployResult.value = response.data

        addLog('App registered, connecting to deploy stream...', 'text-blue-400')

        // Step 2: Connect to SSE stream for real-time progress
        const sseUrl = (stream_url || `/api/v1/apps/${appId}/deploy/stream`)
        const evtSource = new EventSource(sseUrl)

        evtSource.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data)

                // Map status to terminal colors
                const colorMap = {
                    running: 'text-slate-300',
                    success: 'text-emerald-400',
                    warning: 'text-yellow-400',
                    error: 'text-red-500 font-bold'
                }
                const color = colorMap[data.status] || 'text-slate-300'
                const prefix = data.status === 'success' ? '✔ ' :
                               data.status === 'error' ? 'ERROR: ' :
                               data.status === 'warning' ? '⚠ ' : '> '

                addLog(`${prefix}${data.message}`, color)

                if (data.done) {
                    evtSource.close()

                    if (data.status === 'success') {
                        // Merge final deploy data
                        if (data.data) {
                            deployResult.value = { ...deployResult.value, ...data.data }
                        }
                        addLog('Deployment completed successfully!', 'text-emerald-300 font-bold')
                        setTimeout(() => { step.value = 5 }, 1500)
                    } else {
                        errorMessage.value = data.message || 'Deployment failed'
                        loading.value = false
                    }
                }
            } catch (parseErr) {
                console.warn('Failed to parse SSE event:', event.data)
            }
        }

        evtSource.onerror = () => {
            evtSource.close()
            // If we haven't received a completion event, fall back to polling
            if (loading.value && step.value === 4) {
                addLog('Stream disconnected, polling for status...', 'text-yellow-400')
                pollDeployStatus(appId)
            }
        }

    } catch (e) {
        console.error(e)
        const detail = e.response?.data?.detail
        let errorMsg = typeof detail === 'string' ? detail : Array.isArray(detail) ? detail.map(d => d.msg || JSON.stringify(d)).join('; ') : JSON.stringify(detail || 'Deployment Failed')
        errorMsg = errorMsg
            .replace(/https:\/\/[^@]+@/g, 'https://***@')
            .replace(/ATATT[A-Za-z0-9_=-]+/g, '***')
        addLog(`ERROR: ${errorMsg}`, 'text-red-500 font-bold')
        errorMessage.value = errorMsg
        loading.value = false
    }
}

// Fallback: poll app status if SSE stream disconnects
const pollDeployStatus = async (appId) => {
    for (let i = 0; i < 60; i++) {
        await new Promise(r => setTimeout(r, 3000))
        try {
            const { data } = await axios.get(`/api/v1/apps/${form.name}`)
            if (data.status === 'running' || data.status === 'healthy') {
                deployResult.value = data
                addLog('Deployment completed.', 'text-emerald-400')
                setTimeout(() => { step.value = 5 }, 1000)
                return
            } else if (data.status === 'error') {
                addLog(`Deploy error: ${data.error || 'Unknown'}`, 'text-red-500')
                errorMessage.value = data.error || 'Deployment failed'
                loading.value = false
                return
            }
        } catch { /* continue polling */ }
    }
    addLog('Timed out waiting for deployment status', 'text-yellow-400')
    loading.value = false
}
</script>

<style scoped>
.animate-progress {
    animation: progress 2s ease-in-out infinite;
}

@keyframes progress {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}

.custom-scrollbar::-webkit-scrollbar {
    width: 4px;
}
.custom-scrollbar::-webkit-scrollbar-track {
    background: transparent;
}
.custom-scrollbar::-webkit-scrollbar-thumb {
    background: rgba(255,255,255,0.1);
    border-radius: 2px;
}
.custom-scrollbar::-webkit-scrollbar-thumb:hover {
    background: rgba(255,255,255,0.2);
}

.animate-fade-in {
    animation: fadeIn 0.3s ease-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}
</style>
